MindCrafters - TAEval
=====================

## Documentation
All documentation for each of the design components can be found in `documents/`.

All source code for the prorotye deliverables can be found in the `code/` directory.

## Build/Run
Specifications to build and run can be found in [code/README.md](/code/README.md)



## Members

  * Owen MacWilliam
    * Role: ???



  * Bheesham Persaud 
    * Role: Configuration


  * Ado Chaddad
    * Role: ???


  * Martin Gingras
    * Role: Leader
