Mindcrafters:
---
 
###Build/Run the Client/Server:
 
 1. Build the Server (from main project directory):
   1. "$ cd Server/Server"
   2. "$ make clean && make"
 
 2. Build the client (from main project directory):
   1. "cd TAEval/TAEval"
   2. "make clean && make"
 
 3. From the project root directory, Run the Server executable:
   "./Server/Server"
   
   Later you will need the Host IP address. To find the IP address to use for the TAEval client;
   - If using the TAEval client on the host machine, use the IPv4 address printed when server starts
   - If using the TAEval client on a VM on the network, use the IPv4 address of the host machine (if windows, go to: Start -> enter "cmd.exe" -> enter ipconfig -> record the iPv4 address under Ethernet adapter)
   
 4. From the project root directory, Run the Client executable:
   Linux: "./TAEval/TAEval"
   
 5. You will then be prompted for an IP Address, use the one recorded from step 3 when starting your server.
 

 
 
###Server
#####Code found under Server directory
 
###Client
#####Code found under TAEval directory
 
###Alternative build/run directives
 
####To run using QT Creator: (note, running the Server through QT requires you to set the terminal to xTerm)
 1. Open QT Creator
 2. Go to File > Open File or Project...
 3. Browse to:
   * "TAEval/TAEval/TAEval.pro" (For Client code)
   * "Server/Server/Server.pro" (For Server code)
 4. Click Open
 (Server then Client)
 5. Right click project -> Clean Project
 6 Right click project -> Build
 7. Right click project -> Run
