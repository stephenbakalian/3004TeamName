#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "clientrequest.h"
#include <iostream>
#include <string>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    // Ask for the IP address
    bool ok;
    QString ipAddress = QInputDialog::getText(this, tr("TAEval"),
            tr("IP Address of server:"), QLineEdit::Normal,
            "", &ok);
    if (!ok || ipAddress.isEmpty()) {
        QMessageBox errorBox;
        errorBox.setWindowTitle(tr("TAEval - Error"));
        errorBox.setText("Invalid IP Address");
        errorBox.setStandardButtons(QMessageBox::Ok);
        errorBox.setDefaultButton(QMessageBox::Ok);
        errorBox.exec();
        this->close();
    }

    qint16 portNum = 60006;

    cr = new ClientRequest(ipAddress, portNum);
    connect(cr, SIGNAL(generalError(QString)), this, SLOT(handleError(QString)));
    connect(cr, SIGNAL(connectionRefusedError(QString)), this, SLOT(handleError(QString)));
    connect(cr, SIGNAL(remoteHostClosedError(QString)), this, SLOT(handleError(QString)));

    currUser = new CurrentUser();
    ui->setupUi(this);
    ui->stackedWidget->setCurrentWidget(ui->loginPage);

}

void MainWindow::handleError(QString error) {
    QMessageBox errorBox;
    errorBox.setWindowTitle(tr("TAEval - Error"));
    errorBox.setText(error);
    errorBox.setStandardButtons(QMessageBox::Ok);
    errorBox.setDefaultButton(QMessageBox::Ok);
    errorBox.exec();
    this->close();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionQuit_triggered()
{
    this->close();
}

// Save task
void MainWindow::on_taskForm_button_save_clicked()
{
    QString status;
    if(ui->viewTask_mode_label->text() == "Edit Task"){
                status = cr->instructorEditTask(ui->viewCourse_TaskID_label->text().toInt(), ui->viewTask_taUsername_label->text(), ui->viewTask_taskName->text(), ui->viewTask_dutiesGoals->toPlainText());
                if(status.split("\n").at(0) != "success"){
                    //Handle failure to-do
                    qDebug() << status;
                }
                status = cr->instructorSaveEvaluationData(ui->viewCourse_TaskID_label->text().toInt(), ui->viewTask_rating->value(), ui->viewTask_feedback->toPlainText());
                if(status.split("\n").at(0) != "success"){
                    //Handle failure to-do
                    qDebug() << status;
                }
    }
    else if(ui->viewTask_mode_label->text() == "Add Task"){
        status = cr->instructorAddTask(ui->viewTask_taUsername_label->text(), ui->viewTask_taskName->text(), ui->viewTask_dutiesGoals->toPlainText());
        if(status.split("\n").at(0) != "success"){
            //Handle failure to-do
            qDebug() << status;
        }
    }
    ui->stackedWidget->setCurrentWidget(ui->browsePage);
    browseTasks(ui->viewTask_taUsername_label->text());
}

// Get rid of all info, revert back to the home page
void MainWindow::on_taskForm_button_cancel_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->browsePage);
}

void MainWindow::on_login_button_clicked()
{
    bool ok;
    QString username = ui->username_input->text();
    QString resp = cr->userLogin(username);
    QStringList tempList = resp.split("\n");
    if (resp.startsWith("success") && (UserType) tempList.at(2).toInt() != ADMINISTRATOR_USER) {
        currUser->setUsername(username);
        currUser->setUserType((UserType) tempList.at(2).toInt());
        ok = true;
    }
    else{
        ok = false;
        ui->login_failed_text->show();
    }
    if (!username.isEmpty() && ok) {
        ui->login_button->setEnabled(false);  // To stop continuous clicking of enter triggering shit...
        ui->stackedWidget->setCurrentWidget(ui->browsePage);
        ui->browse_username_label->setText(username);
        switch(currUser->getUserType()){
        case TA_USER:
        {
//            ui->browse_action_label->setText("task to review:");
            browseTasks(username);
            break;
        }
        case INSTRUCTOR_USER:
        {
            browseCourses();
            break;
        }
        case ADMINISTRATOR_USER:
        {
            ui->browse_action_label->setText("Do yo crazy admin shiit");
            break;
        }
        default:
            ui->browse_action_label->setText("You should never get here!!!");
        }
    }
    else{
        ui->login_failed_text->setText("Login Failed...");
    }
}
void MainWindow::on_username_input_returnPressed()
{
    ui->login_button->click();
}

void MainWindow::on_browse_selection_pane_itemSelectionChanged()
{
       ui->browse_push_button->setEnabled(true);
       ui->browse_delete_task_button->setEnabled(true);
}

void MainWindow::on_browse_push_button_clicked()
{
    qDebug() << currUser->getView();
    if(currUser->getView() == "viewCourses"){
        currUser->getCourseSelected().clear();
        QStringList course;
        course << ui->browse_tableWidget->selectedItems().at(0)->text()
               <<  ui->browse_tableWidget->selectedItems().at(1)->text()
               <<  ui->browse_tableWidget->selectedItems().at(2)->text()
               << ui->browse_tableWidget->selectedItems().at(3)->text()
               << ui->browse_tableWidget->selectedItems().at(4)->text();
        currUser->setCourseSelected(course);
        browseTAs(currUser->getCourseSelected());
    }
    else if(currUser->getView() == "viewTasks"){
        if(currUser->getUserType() == TA_USER){
            viewTask(currUser->getUsername(), "viewTask");
        }
        else{
            viewTask(ui->browse_username_label->text(), "editTask");
        }
    }
    else if(currUser->getView() == "viewTAs"){
        QString ta = ui->browse_selection_pane->selectedItems().at(0)->text();
        browseTasks(ta);
    }
    else{
        qDebug() << "You shouldn't be here, mainwindow.cpp:" << __LINE__;
    }
}

void MainWindow::browseTAs(QStringList courseData){
    // UI management
    ui->browse_tableWidget->hide();
    ui->browse_selection_pane->show();
    ui->backButton->show();
    ui->browse_action_label->setText("TA to view tasks for:");
    ui->browse_selection_pane->clear();
    ui->browse_selection_pane->setEnabled(true);
    ui->browse_add_task_button->hide();
    ui->browse_delete_task_button->hide();
    ui->browse_push_button->setText("Select");

    // Capitalize term
    std::string temp = courseData.at(2).toStdString();
    temp[0] = courseData.at(2).at(0).toUpper().toAscii();
    QString course = courseData.at(0) + courseData.at(1) + " in " + QString::fromStdString(temp) + " " + courseData.at(3);
    ui->browse_username_label->setText(course);
    int courseID = courseData.at(4).toInt();

    QStringList allTAs = cr->instructorViewTAsForCourse(courseID).split("\n");
    if (allTAs[0] == "error") {
        qDebug() << "Error!: " << allTAs;
        handleError("Error getting TAs for Course");
        return;
    }
    allTAs.pop_front();
    ui->browse_selection_pane->addItems(allTAs);


    QFont font;
    font.setFamily("Helvetica");
    font.setPointSize(14);
    ui->browse_username_label->setFont(font);
    ui->browse_heading_label->setText("TAs for: ");
    ui->browse_push_button->setEnabled(false);
    currUser->setView("viewTAs");
}

void MainWindow::browseCourses(){
    // UI manipulation
    ui->backButton->hide();
    ui->browse_push_button->setText("Select");
    ui->browse_delete_task_button->hide();
    ui->browse_add_task_button->hide();
    ui->browse_action_label->setText("course to view the TA's for:");
    ui->browse_heading_label->setText("Welcome:");
    ui->browse_username_label->setText(currUser->getUsername());

    ui->browse_tableWidget->show();
    ui->browse_tableWidget->clear();
    ui->browse_tableWidget->clearSelection();
    ui->browse_selection_pane->setEnabled(false);
    ui->browse_selection_pane->hide();
    ui->browse_push_button->setEnabled(false);

    QFont font;
    font.setPointSize(24);
    ui->browse_username_label->setFont(font);

    QStringList allCourses = cr->instructorViewCourses().split("\n");
    if (allCourses[0] == "error") {
        // Handle Error... to-do
        return;
    }
    allCourses.pop_front();
    currUser->setView("viewCourses");

    ui->browse_tableWidget->setColumnCount(5);
    ui->browse_tableWidget->setRowCount(allCourses.size());
    QStringList headings;
    headings << "Course Code" << "Section" << "Term" << "Year" << "CourseID";
    ui->browse_tableWidget->setHorizontalHeaderLabels(headings);
    ui->browse_tableWidget->setColumnWidth(0,100);
    ui->browse_tableWidget->setColumnWidth(1,59);
    ui->browse_tableWidget->setColumnWidth(2,65);
    ui->browse_tableWidget->setColumnWidth(3,64);
    ui->browse_tableWidget->setColumnWidth(4,110);

    QString temp;
    QStringList data;
    QTableWidgetItem *cell;
    for (int i = 0; i < allCourses.size(); ++i) {
        temp = allCourses.at(i);
        data = temp.split(",\t");
        for(int j = 0; j < data.size(); j++){
            cell = new QTableWidgetItem(data.at(j));
            ui->browse_tableWidget->setItem(i,j,cell);
        }
    }
}

void MainWindow::browseTasks(QString ta){
    ui->browse_tableWidget->clearSelection();
    ui->browse_push_button->setEnabled(false);
    if(currUser->getUserType() == TA_USER){
        ui->browse_add_task_button->hide();
        ui->browse_delete_task_button->hide();
        ui->backButton->hide();
    }
    else{
        ui->backButton->show();
    }
    QStringList tasks = cr->viewTasksForTA(ta).split("\n");
    if (tasks[0] == "error") {
        qDebug() << "Error!: " << tasks;
        handleError("Error getting tasks for TA");
        return;
    }
    tasks.pop_front();
    currUser->setView("viewTasks");
    ui->browse_selection_pane->clear();
    ui->browse_push_button->setEnabled(false);
    if(currUser->getUserType() == TA_USER){
        ui->browse_push_button->setText("View Task");
    }
    else if(currUser->getUserType() == INSTRUCTOR_USER){
        ui->browse_push_button->setText("Edit/Evaluate Task");
        ui->browse_add_task_button->show();
        ui->browse_delete_task_button->setEnabled(false);
        ui->browse_delete_task_button->show();
    }
    ui->browse_heading_label->setText("Tasks for: ");
    ui->browse_username_label->setText(ta);
    ui->browse_action_label->setText("task to review:");
    if(tasks.length() > 0){
        ui->browse_tableWidget->show();
        ui->browse_selection_pane->hide();
        ui->browse_tableWidget->setColumnCount(2);
        ui->browse_tableWidget->setRowCount(tasks.size());
        QStringList headings;
        headings << "TaskID" << "Task Title";
        ui->browse_tableWidget->setHorizontalHeaderLabels(headings);
        ui->browse_tableWidget->setColumnWidth(0,89);
        ui->browse_tableWidget->setColumnWidth(1,309);
        QString temp;
        QStringList data;
        QTableWidgetItem *cell;
        for (int i = 0; i < tasks.size(); ++i) {
            temp = tasks.at(i);
            data = temp.split(",\t");
            for(int j = 0; j < 2; j++){
                cell = new QTableWidgetItem(data.at(j));
                ui->browse_tableWidget->setItem(i,j,cell);
            }
        }
    }
    else{
        ui->browse_tableWidget->hide();
        ui->browse_selection_pane->show();
        ui->browse_selection_pane->addItem("No Tasks");
        ui->browse_selection_pane->setEnabled(false);
        ui->browse_push_button->setEnabled(false);
        ui->browse_delete_task_button->setEnabled(false);
    }
}

void MainWindow::viewTask(QString ta, QString mode){
    ui->stackedWidget->setCurrentWidget(ui->viewTask);
    ui->viewCourse_TaskID_label->hide();
    ui->viewTask_taUsername_label->setText(ta);

    // Clean up
    ui->viewTask_rating->setValue(5);
    ui->viewTask_dutiesGoals->clear();
    ui->viewTask_feedback->clear();
    ui->viewTask_taskName->clear();
    // Show all elements
    ui->taskForm_button_cancel->show();
    ui->viewTask_feedback->show();
    ui->viewTask_rating->show();
    ui->viewTask_evalData_label->show();
    ui->viewTask_feedback_label->show();
    ui->viewTask_ratingLabel->show();

    if(currUser->getUserType() == TA_USER){
        // Change save to Done
        ui->taskForm_button_save->setText("Done");
        // Hide irrelevant button
        ui->taskForm_button_cancel->hide();
        // Disable editing anything!
        ui->viewTask_feedback->setEnabled(false);
        ui->viewTask_dutiesGoals->setEnabled(false);
        ui->viewTask_rating->setEnabled(false);
        ui->viewTask_taskName->setEnabled(false);
    }
    else{
        // Change save to Done
        ui->taskForm_button_save->setText("Save");
        // Enable editing things
        ui->viewTask_feedback->setEnabled(true);
        ui->viewTask_dutiesGoals->setEnabled(true);
        ui->viewTask_rating->setEnabled(true);
        ui->viewTask_taskName->setEnabled(true);
    }
    if(mode == "addTask"){
        ui->viewTask_feedback->hide();
        ui->viewTask_rating->hide();
        ui->viewTask_evalData_label->hide();
        ui->viewTask_feedback_label->hide();
        ui->viewTask_ratingLabel->hide();
        ui->viewTask_mode_label->setText("Add Task");
    }
    else if(mode == "editTask"){
        ui->viewTask_mode_label->setText("Edit Task");
        int taskID = ui->browse_tableWidget->selectedItems().at(0)->text().toInt();
//        qDebug() << taskID;
        QStringList taskInfo = cr->instructorViewTask(taskID).split("\n");
        if (taskInfo.at(0) == "error") {
            handleError("Error getting task info");
            qDebug() << "Error: " << taskInfo;
            return;
        }
        taskInfo.pop_front();
        ui->viewCourse_TaskID_label->show();
        ui->viewCourse_TaskID_label->setText(taskInfo.at(0));
        ui->viewTask_taskName->setText(taskInfo.at(1));
        ui->viewTask_dutiesGoals->setPlainText(QString(QByteArray::fromBase64(taskInfo.at(3).toStdString().c_str())));
        // Has eval data
        if(taskInfo.size() == 6){
            ui->viewTask_rating->setValue(taskInfo.at(4).toInt());
            ui->viewTask_feedback->setPlainText(QString(QByteArray::fromBase64(taskInfo.at(5).toStdString().c_str())));
        }
    }
    else if(mode == "viewTask"){
        ui->viewTask_mode_label->setText("View Task");
        int taskID = ui->browse_tableWidget->selectedItems().at(0)->text().toInt();
//        qDebug() << taskID;
        QStringList taskInfo = cr->instructorViewTask(taskID).split("\n");
        if (taskInfo.at(0) == "error") {
            handleError("Error getting task info");
            qDebug() << "Error: " << taskInfo;
            return;
        }
        taskInfo.pop_front();
        ui->viewCourse_TaskID_label->show();
        ui->viewCourse_TaskID_label->setText(taskInfo.at(0));
        ui->viewTask_taskName->setText(taskInfo.at(1));
        ui->viewTask_dutiesGoals->setPlainText(QString(QByteArray::fromBase64(taskInfo.at(3).toStdString().c_str())));
        // Has eval data
        if(taskInfo.size() == 6){
            ui->viewTask_rating->setValue(taskInfo.at(4).toInt());
            ui->viewTask_feedback->setPlainText(QString(QByteArray::fromBase64(taskInfo.at(5).toStdString().c_str())));
        }
        else{
            ui->viewTask_feedback->hide();
            ui->viewTask_rating->hide();
            ui->viewTask_evalData_label->hide();
            ui->viewTask_feedback_label->hide();
            ui->viewTask_ratingLabel->hide();
        }


    }
}

void MainWindow::on_browse_add_task_button_clicked()
{
    viewTask(ui->browse_username_label->text() ,"addTask");
}

void MainWindow::on_browse_delete_task_button_clicked()
{
    QString status = cr->instructorDeleteTask(ui->browse_tableWidget->selectedItems().at(0)->text().toInt());
    if(status.split("\n").at(0) != "success"){
        //Handle failure to-do
        qDebug() << status;
    }
    else{
        ui->browse_selection_pane->clear();
        ui->browse_tableWidget->clearSelection();
        ui->browse_push_button->setEnabled(false);
        browseTasks(ui->browse_username_label->text());
    }
}

void MainWindow::on_backButton_clicked()
{
    qDebug() << currUser->getView();
    if(currUser->getView() == "viewTAs"){
        browseCourses();
    }
    else if(currUser->getView() == "viewTasks")
    {
        browseTAs(currUser->getCourseSelected());
    }
}

void MainWindow::on_logoutButton_clicked()
{
    QString status = cr->userLogout();
    if (status.startsWith("success")) {
        currUser->setUsername("");
        currUser->getCourseSelected().clear();
        currUser->setUserType(TA_USER);
//        qDebug() << status;
        ui->login_button->setDisabled(false);
        ui->username_input->clear();
        ui->login_failed_text->hide();
        ui->stackedWidget->setCurrentWidget(ui->loginPage);
    }
    else{
        qDebug() << "Error Logging Off!!!";
    }
}

void MainWindow::on_browse_selection_pane_activated()
{
    ui->browse_push_button->click();
}

void MainWindow::on_browse_tableWidget_itemActivated()
{
    ui->browse_push_button->click();
}

void MainWindow::on_browse_tableWidget_itemSelectionChanged()
{
    ui->browse_push_button->setEnabled(true);
    ui->browse_delete_task_button->setEnabled(true);
}

void MainWindow::on_actionAbout_triggered()
{
    About* aboutUI = new About(this);
    aboutUI->show();
}
