/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Mon Dec 9 12:51:44 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,   12,   11,   11, 0x08,
      39,   11,   11,   11, 0x08,
      65,   11,   11,   11, 0x08,
      99,   11,   11,   11, 0x08,
     135,   11,   11,   11, 0x08,
     161,   11,   11,   11, 0x08,
     195,   11,   11,   11, 0x08,
     243,   11,   11,   11, 0x08,
     278,  275,   11,   11, 0x08,
     299,   11,   11,   11, 0x08,
     326,  315,   11,   11, 0x08,
     357,  349,   11,   11, 0x08,
     383,   11,   11,   11, 0x08,
     419,   11,   11,   11, 0x08,
     458,   11,   11,   11, 0x08,
     482,   11,   11,   11, 0x08,
     508,   11,   11,   11, 0x08,
     545,   11,   11,   11, 0x08,
     583,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0error\0handleError(QString)\0"
    "on_actionQuit_triggered()\0"
    "on_taskForm_button_save_clicked()\0"
    "on_taskForm_button_cancel_clicked()\0"
    "on_login_button_clicked()\0"
    "on_username_input_returnPressed()\0"
    "on_browse_selection_pane_itemSelectionChanged()\0"
    "on_browse_push_button_clicked()\0ta\0"
    "browseTasks(QString)\0browseCourses()\0"
    "courseData\0browseTAs(QStringList)\0"
    "ta,mode\0viewTask(QString,QString)\0"
    "on_browse_add_task_button_clicked()\0"
    "on_browse_delete_task_button_clicked()\0"
    "on_backButton_clicked()\0"
    "on_logoutButton_clicked()\0"
    "on_browse_selection_pane_activated()\0"
    "on_browse_tableWidget_itemActivated()\0"
    "on_browse_tableWidget_itemSelectionChanged()\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->handleError((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->on_actionQuit_triggered(); break;
        case 2: _t->on_taskForm_button_save_clicked(); break;
        case 3: _t->on_taskForm_button_cancel_clicked(); break;
        case 4: _t->on_login_button_clicked(); break;
        case 5: _t->on_username_input_returnPressed(); break;
        case 6: _t->on_browse_selection_pane_itemSelectionChanged(); break;
        case 7: _t->on_browse_push_button_clicked(); break;
        case 8: _t->browseTasks((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->browseCourses(); break;
        case 10: _t->browseTAs((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 11: _t->viewTask((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 12: _t->on_browse_add_task_button_clicked(); break;
        case 13: _t->on_browse_delete_task_button_clicked(); break;
        case 14: _t->on_backButton_clicked(); break;
        case 15: _t->on_logoutButton_clicked(); break;
        case 16: _t->on_browse_selection_pane_activated(); break;
        case 17: _t->on_browse_tableWidget_itemActivated(); break;
        case 18: _t->on_browse_tableWidget_itemSelectionChanged(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
