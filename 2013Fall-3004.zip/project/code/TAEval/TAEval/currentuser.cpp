#include "currentuser.h"

CurrentUser::CurrentUser()
{
}
UserType CurrentUser::getUserType() const
{
    return userType;
}

void CurrentUser::setUserType(const UserType &value)
{
    userType = value;
}
QString CurrentUser::getUsername() const
{
    return username;
}

void CurrentUser::setUsername(const QString &value)
{
    username = value;
}
QStringList CurrentUser::getCourseSelected() const
{
    return courseSelected;
}

void CurrentUser::setCourseSelected(QStringList value)
{
    courseSelected = value;
}
QString CurrentUser::getView() const
{
    return view;
}

void CurrentUser::setView(const QString &value)
{
    view = value;
}




