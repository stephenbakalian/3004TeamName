#include "clientrequest.h"

ClientRequest::ClientRequest(QString ipAddress, qint16 portNum) {
    tcpSocket = new QTcpSocket();

    connect(tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)),
             this, SLOT(displayError(QAbstractSocket::SocketError)));

    tcpSocket->connectToHost(ipAddress, portNum);
}

QString ClientRequest::instructorViewCourses() {
    QString request(QString::number(VIEW_COURSES));
//    qDebug() << request;
    request += "\n";
    QString resp = sendRequest(request);
//    qDebug() << resp;
    return resp;
}

QString ClientRequest::instructorViewTasks() {
    QString request(QString::number(VIEW_TASKS));
    request += "\n";
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::instructorViewTask(int taskID) {
    QString request(QString::number(VIEW_TASK));
//    qDebug() << request;
    request += "\n";
    request += QString::number(taskID);
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::instructorViewTAs() {
    QString request(QString::number(VIEW_TAS));
    request += "\n";
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::instructorViewTAsForCourse(int courseID) {
    QString request(QString::number(VIEW_TAS_FOR_COURSE));
    request += "\n";
    request += QString::number(courseID);
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::instructorAddTask(QString taUsername, QString taskName, QString goalsAndDuties) {
    QString request(QString::number(ADD_TASK));
    request += "\n";
    request += taUsername + "\n";
    request += taskName + "\n";
    request += QString(QByteArray(goalsAndDuties.toStdString().c_str()).toBase64());
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::viewTasksForTA(QString TA) {
    QString request(QString::number(VIEW_TASKS));
//    qDebug() << request;
    request += "\n";
    request += TA;
    return sendRequest(request);
}

QString ClientRequest::instructorEditTask(int taskID, QString taUsername, QString taskName, QString goalsAndDuties) {
    QString request(QString::number(EDIT_TASK));
    request += "\n";
    request += QString::number(taskID) + "\n";
    request += taUsername + "\n";
    request += taskName + "\n";
    request += QString(QByteArray(goalsAndDuties.toStdString().c_str()).toBase64());
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::instructorDeleteTask(int taskID) {
    QString request(QString::number(DELETE_TASK));
    request += "\n";
    request += QString::number(taskID);
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::instructorSaveEvaluationData(int taskID, int rating, QString feedback) {
    QString request(QString::number(EVALUATE_TASK));
    request += "\n";
    request += QString::number(taskID) + "\n";
    request += QString::number(rating) + "\n";
    request += QString(QByteArray(feedback.toStdString().c_str()).toBase64());
    QString resp = sendRequest(request);
    return resp;
}

QString ClientRequest::userLogin(QString username) {
    // First, log out.
    userLogout();

    QString request(QString::number(LOGIN));
    request += "\n";
    request += username;

    return sendRequest(request);
}

QString ClientRequest::userLogout() {
    QString request(QString::number(LOGOFF));
    request += "\n";
    return sendRequest(request);
}

ClientRequest::~ClientRequest() {
    userLogout();
    tcpSocket->close();
}

QString ClientRequest::sendRequest(QString req) {
    tcpSocket->write(req.toStdString().c_str());
    tcpSocket->waitForReadyRead(-1);
    return QString(tcpSocket->readAll());
}

void ClientRequest::displayError(QAbstractSocket::SocketError err) {
    // For all of the different cases, view
    // http://qt-project.org/doc/qt-4.8/qabstractsocket.html#SocketError-enum
    switch(err) {
        case QAbstractSocket::ConnectionRefusedError:
        emit connectionRefusedError(QString("Connection to server refused."));
            break;

        case QAbstractSocket::RemoteHostClosedError:
        emit remoteHostClosedError(QString("Connection to server closed."));
            break;

        default:
        emit generalError(QString("Could not communicate with the server."));
            break;
    }
}
