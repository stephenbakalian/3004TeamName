#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDebug>
#include <QMainWindow>
#include <QInputDialog>
#include <QMessageBox>

#include "about.h"
#include "clientrequest.h"
#include "currentuser.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void handleError(QString error);

    void on_actionQuit_triggered();

    //Instructor page






    // to-do rename these
    void on_taskForm_button_save_clicked();
    void on_taskForm_button_cancel_clicked();


    // HANDLERS FOR ACTUAL APP
    void on_login_button_clicked();

    void on_username_input_returnPressed();

    void on_browse_selection_pane_itemSelectionChanged();

    void on_browse_push_button_clicked();

    void browseTasks(QString ta);

    void browseCourses();

    void browseTAs(QStringList courseData);

    void viewTask(QString ta, QString mode);

    void on_browse_add_task_button_clicked();

    void on_browse_delete_task_button_clicked();

    void on_backButton_clicked();

    void on_logoutButton_clicked();

    void on_browse_selection_pane_activated();

    void on_browse_tableWidget_itemActivated();

    void on_browse_tableWidget_itemSelectionChanged();

    void on_actionAbout_triggered();

private:
    Ui::MainWindow *ui;
    ClientRequest *cr;
    CurrentUser   *currUser;
};

#endif // MAINWINDOW_H
