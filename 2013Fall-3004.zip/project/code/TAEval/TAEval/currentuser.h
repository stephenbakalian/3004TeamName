#ifndef CURRENTUSER_H
#define CURRENTUSER_H

#include <QString>
#include <QStringList>


/************ MUST MATCH ENUM IN user.h on Server *************/
enum UserType {TA_USER, INSTRUCTOR_USER, ADMINISTRATOR_USER};
/**************************************************************/

class CurrentUser
{
public:
    CurrentUser();

    UserType getUserType() const;
    void setUserType(const UserType &value);

    QString getUsername() const;
    void setUsername(const QString &value);

    QStringList getCourseSelected() const;
    void setCourseSelected(QStringList value);

    QString getView() const;
    void setView(const QString &value);

private:
    QString username;
    UserType userType;
    QStringList courseSelected;
    QString view;
};

#endif // CURRENTUSER_H
