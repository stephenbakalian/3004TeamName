/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon Dec 9 12:51:36 2013
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QStackedWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionQuit;
    QAction *actionAbout;
    QWidget *centralWidget;
    QStackedWidget *stackedWidget;
    QWidget *viewTask;
    QWidget *verticalLayoutWidget_8;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_4;
    QLabel *viewTask_mode_label;
    QLabel *viewCourse_TaskID_label;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_3;
    QLabel *viewTask_taUsername_label;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *viewTask_taskName;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_4;
    QPlainTextEdit *viewTask_dutiesGoals;
    QWidget *verticalLayoutWidget_9;
    QVBoxLayout *verticalLayout_6;
    QPushButton *taskForm_button_save;
    QPushButton *taskForm_button_cancel;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_7;
    QLabel *viewTask_evalData_label;
    QHBoxLayout *horizontalLayout_2;
    QLabel *viewTask_ratingLabel;
    QSpinBox *viewTask_rating;
    QLabel *viewTask_feedback_label;
    QPlainTextEdit *viewTask_feedback;
    QWidget *loginPage;
    QLabel *login_label_title;
    QLabel *login_label_username;
    QPushButton *login_button;
    QLineEdit *username_input;
    QLabel *login_failed_text;
    QWidget *browsePage;
    QLabel *browse_heading_label;
    QLabel *browse_username_label;
    QLabel *label_7;
    QLabel *browse_action_label;
    QListWidget *browse_selection_pane;
    QPushButton *browse_push_button;
    QPushButton *browse_add_task_button;
    QPushButton *browse_delete_task_button;
    QPushButton *backButton;
    QPushButton *logoutButton;
    QTableWidget *browse_tableWidget;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuAbout;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(628, 422);
        actionQuit = new QAction(MainWindow);
        actionQuit->setObjectName(QString::fromUtf8("actionQuit"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setMaximumSize(QSize(700, 500));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(-10, 0, 700, 500));
        stackedWidget->setMinimumSize(QSize(700, 400));
        stackedWidget->setMaximumSize(QSize(700, 400));
        stackedWidget->setAutoFillBackground(true);
        viewTask = new QWidget();
        viewTask->setObjectName(QString::fromUtf8("viewTask"));
        verticalLayoutWidget_8 = new QWidget(viewTask);
        verticalLayoutWidget_8->setObjectName(QString::fromUtf8("verticalLayoutWidget_8"));
        verticalLayoutWidget_8->setGeometry(QRect(20, 10, 451, 201));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_8);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        viewTask_mode_label = new QLabel(verticalLayoutWidget_8);
        viewTask_mode_label->setObjectName(QString::fromUtf8("viewTask_mode_label"));

        horizontalLayout_4->addWidget(viewTask_mode_label);

        viewCourse_TaskID_label = new QLabel(verticalLayoutWidget_8);
        viewCourse_TaskID_label->setObjectName(QString::fromUtf8("viewCourse_TaskID_label"));

        horizontalLayout_4->addWidget(viewCourse_TaskID_label);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_3);

        label_3 = new QLabel(verticalLayoutWidget_8);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_4->addWidget(label_3);

        viewTask_taUsername_label = new QLabel(verticalLayoutWidget_8);
        viewTask_taUsername_label->setObjectName(QString::fromUtf8("viewTask_taUsername_label"));

        horizontalLayout_4->addWidget(viewTask_taUsername_label);


        verticalLayout_5->addLayout(horizontalLayout_4);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(verticalLayoutWidget_8);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_3->addWidget(label_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        viewTask_taskName = new QLineEdit(verticalLayoutWidget_8);
        viewTask_taskName->setObjectName(QString::fromUtf8("viewTask_taskName"));

        horizontalLayout_3->addWidget(viewTask_taskName);


        verticalLayout_5->addLayout(horizontalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_4 = new QLabel(verticalLayoutWidget_8);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_4->addWidget(label_4);

        viewTask_dutiesGoals = new QPlainTextEdit(verticalLayoutWidget_8);
        viewTask_dutiesGoals->setObjectName(QString::fromUtf8("viewTask_dutiesGoals"));

        verticalLayout_4->addWidget(viewTask_dutiesGoals);


        verticalLayout_5->addLayout(verticalLayout_4);

        verticalLayoutWidget_9 = new QWidget(viewTask);
        verticalLayoutWidget_9->setObjectName(QString::fromUtf8("verticalLayoutWidget_9"));
        verticalLayoutWidget_9->setGeometry(QRect(480, 10, 131, 131));
        verticalLayout_6 = new QVBoxLayout(verticalLayoutWidget_9);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        taskForm_button_save = new QPushButton(verticalLayoutWidget_9);
        taskForm_button_save->setObjectName(QString::fromUtf8("taskForm_button_save"));

        verticalLayout_6->addWidget(taskForm_button_save);

        taskForm_button_cancel = new QPushButton(verticalLayoutWidget_9);
        taskForm_button_cancel->setObjectName(QString::fromUtf8("taskForm_button_cancel"));

        verticalLayout_6->addWidget(taskForm_button_cancel);

        verticalLayoutWidget = new QWidget(viewTask);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(20, 216, 451, 159));
        verticalLayout_7 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        viewTask_evalData_label = new QLabel(verticalLayoutWidget);
        viewTask_evalData_label->setObjectName(QString::fromUtf8("viewTask_evalData_label"));

        verticalLayout_7->addWidget(viewTask_evalData_label);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        viewTask_ratingLabel = new QLabel(verticalLayoutWidget);
        viewTask_ratingLabel->setObjectName(QString::fromUtf8("viewTask_ratingLabel"));

        horizontalLayout_2->addWidget(viewTask_ratingLabel);

        viewTask_rating = new QSpinBox(verticalLayoutWidget);
        viewTask_rating->setObjectName(QString::fromUtf8("viewTask_rating"));
        viewTask_rating->setMaximum(10);
        viewTask_rating->setValue(5);

        horizontalLayout_2->addWidget(viewTask_rating);


        verticalLayout_7->addLayout(horizontalLayout_2);

        viewTask_feedback_label = new QLabel(verticalLayoutWidget);
        viewTask_feedback_label->setObjectName(QString::fromUtf8("viewTask_feedback_label"));

        verticalLayout_7->addWidget(viewTask_feedback_label);

        viewTask_feedback = new QPlainTextEdit(verticalLayoutWidget);
        viewTask_feedback->setObjectName(QString::fromUtf8("viewTask_feedback"));
        viewTask_feedback->setEnabled(true);

        verticalLayout_7->addWidget(viewTask_feedback);

        stackedWidget->addWidget(viewTask);
        loginPage = new QWidget();
        loginPage->setObjectName(QString::fromUtf8("loginPage"));
        loginPage->setEnabled(true);
        login_label_title = new QLabel(loginPage);
        login_label_title->setObjectName(QString::fromUtf8("login_label_title"));
        login_label_title->setGeometry(QRect(180, 90, 171, 61));
        QFont font;
        font.setPointSize(36);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        login_label_title->setFont(font);
        login_label_username = new QLabel(loginPage);
        login_label_username->setObjectName(QString::fromUtf8("login_label_username"));
        login_label_username->setGeometry(QRect(170, 180, 71, 21));
        login_button = new QPushButton(loginPage);
        login_button->setObjectName(QString::fromUtf8("login_button"));
        login_button->setEnabled(true);
        login_button->setGeometry(QRect(360, 180, 110, 21));
        login_button->setCheckable(false);
        login_button->setAutoDefault(true);
        login_button->setDefault(true);
        username_input = new QLineEdit(loginPage);
        username_input->setObjectName(QString::fromUtf8("username_input"));
        username_input->setEnabled(true);
        username_input->setGeometry(QRect(240, 180, 113, 21));
        username_input->setMaxLength(25);
        login_failed_text = new QLabel(loginPage);
        login_failed_text->setObjectName(QString::fromUtf8("login_failed_text"));
        login_failed_text->setGeometry(QRect(240, 210, 111, 16));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(true);
        font1.setWeight(50);
        login_failed_text->setFont(font1);
        stackedWidget->addWidget(loginPage);
        browsePage = new QWidget();
        browsePage->setObjectName(QString::fromUtf8("browsePage"));
        browse_heading_label = new QLabel(browsePage);
        browse_heading_label->setObjectName(QString::fromUtf8("browse_heading_label"));
        browse_heading_label->setGeometry(QRect(150, 50, 61, 20));
        browse_username_label = new QLabel(browsePage);
        browse_username_label->setObjectName(QString::fromUtf8("browse_username_label"));
        browse_username_label->setGeometry(QRect(210, 20, 261, 81));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Ubuntu"));
        font2.setPointSize(24);
        font2.setItalic(true);
        browse_username_label->setFont(font2);
        label_7 = new QLabel(browsePage);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(60, 110, 101, 16));
        browse_action_label = new QLabel(browsePage);
        browse_action_label->setObjectName(QString::fromUtf8("browse_action_label"));
        browse_action_label->setGeometry(QRect(150, 110, 311, 16));
        browse_selection_pane = new QListWidget(browsePage);
        browse_selection_pane->setObjectName(QString::fromUtf8("browse_selection_pane"));
        browse_selection_pane->setGeometry(QRect(60, 130, 400, 200));
        browse_push_button = new QPushButton(browsePage);
        browse_push_button->setObjectName(QString::fromUtf8("browse_push_button"));
        browse_push_button->setEnabled(false);
        browse_push_button->setGeometry(QRect(480, 130, 145, 32));
        browse_push_button->setAutoDefault(false);
        browse_push_button->setDefault(true);
        browse_add_task_button = new QPushButton(browsePage);
        browse_add_task_button->setObjectName(QString::fromUtf8("browse_add_task_button"));
        browse_add_task_button->setEnabled(true);
        browse_add_task_button->setGeometry(QRect(480, 40, 145, 32));
        browse_delete_task_button = new QPushButton(browsePage);
        browse_delete_task_button->setObjectName(QString::fromUtf8("browse_delete_task_button"));
        browse_delete_task_button->setGeometry(QRect(480, 170, 145, 32));
        backButton = new QPushButton(browsePage);
        backButton->setObjectName(QString::fromUtf8("backButton"));
        backButton->setGeometry(QRect(10, 30, 81, 32));
        logoutButton = new QPushButton(browsePage);
        logoutButton->setObjectName(QString::fromUtf8("logoutButton"));
        logoutButton->setGeometry(QRect(10, 0, 81, 32));
        browse_tableWidget = new QTableWidget(browsePage);
        browse_tableWidget->setObjectName(QString::fromUtf8("browse_tableWidget"));
        browse_tableWidget->setEnabled(true);
        browse_tableWidget->setGeometry(QRect(60, 130, 400, 200));
        browse_tableWidget->setAutoFillBackground(false);
        browse_tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        browse_tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        browse_tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        browse_tableWidget->setTextElideMode(Qt::ElideMiddle);
        browse_tableWidget->setShowGrid(true);
        browse_tableWidget->setSortingEnabled(false);
        browse_tableWidget->setCornerButtonEnabled(false);
        browse_tableWidget->verticalHeader()->setVisible(false);
        stackedWidget->addWidget(browsePage);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setEnabled(true);
        menuBar->setGeometry(QRect(0, 0, 628, 24));
        menuBar->setNativeMenuBar(true);
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuAbout = new QMenu(menuBar);
        menuAbout->setObjectName(QString::fromUtf8("menuAbout"));
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuAbout->menuAction());
        menuFile->addAction(actionQuit);
        menuAbout->addAction(actionAbout);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "TAEval", 0, QApplication::UnicodeUTF8));
        actionQuit->setText(QApplication::translate("MainWindow", "Quit", 0, QApplication::UnicodeUTF8));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0, QApplication::UnicodeUTF8));
        viewTask_mode_label->setText(QApplication::translate("MainWindow", "mode", 0, QApplication::UnicodeUTF8));
        viewCourse_TaskID_label->setText(QApplication::translate("MainWindow", "id", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "TA Username:", 0, QApplication::UnicodeUTF8));
        viewTask_taUsername_label->setText(QApplication::translate("MainWindow", "taUsername", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "Task Name", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "Duties and Goals", 0, QApplication::UnicodeUTF8));
        taskForm_button_save->setText(QApplication::translate("MainWindow", "Save", 0, QApplication::UnicodeUTF8));
        taskForm_button_cancel->setText(QApplication::translate("MainWindow", "Cancel", 0, QApplication::UnicodeUTF8));
        viewTask_evalData_label->setText(QApplication::translate("MainWindow", "Evaluation Data:", 0, QApplication::UnicodeUTF8));
        viewTask_ratingLabel->setText(QApplication::translate("MainWindow", "Rating:", 0, QApplication::UnicodeUTF8));
        viewTask_feedback_label->setText(QApplication::translate("MainWindow", "Feedback:", 0, QApplication::UnicodeUTF8));
        login_label_title->setText(QApplication::translate("MainWindow", "TAEval", 0, QApplication::UnicodeUTF8));
        login_label_username->setText(QApplication::translate("MainWindow", "Username:", 0, QApplication::UnicodeUTF8));
        login_button->setText(QApplication::translate("MainWindow", "Login", 0, QApplication::UnicodeUTF8));
        username_input->setText(QString());
        username_input->setPlaceholderText(QApplication::translate("MainWindow", "username", 0, QApplication::UnicodeUTF8));
        login_failed_text->setText(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p><p><br/></p></body></html>", 0, QApplication::UnicodeUTF8));
        browse_heading_label->setText(QApplication::translate("MainWindow", "Welcome:", 0, QApplication::UnicodeUTF8));
        browse_username_label->setText(QString());
        label_7->setText(QApplication::translate("MainWindow", "Please select a ", 0, QApplication::UnicodeUTF8));
        browse_action_label->setText(QString());
        browse_push_button->setText(QApplication::translate("MainWindow", "Select", 0, QApplication::UnicodeUTF8));
        browse_add_task_button->setText(QApplication::translate("MainWindow", "Add Task", 0, QApplication::UnicodeUTF8));
        browse_delete_task_button->setText(QApplication::translate("MainWindow", "Delete Task", 0, QApplication::UnicodeUTF8));
        backButton->setText(QApplication::translate("MainWindow", "\342\206\220 Back", 0, QApplication::UnicodeUTF8));
        logoutButton->setText(QApplication::translate("MainWindow", "Logout", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", 0, QApplication::UnicodeUTF8));
        menuAbout->setTitle(QApplication::translate("MainWindow", "About", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
