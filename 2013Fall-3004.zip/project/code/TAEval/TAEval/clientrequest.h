#ifndef CLIENTREQUEST_H
#define CLIENTREQUEST_H


#include <QtNetwork/QTcpSocket>
#include <QtNetwork/QNetworkSession>
#include <QtNetwork/QNetworkConfiguration>
#include <QtNetwork/QNetworkConfigurationManager>
#include <QEventLoop>

#include <iostream>
#include <string>
#include <QStringList>


/********* MUST MATCH ENUM IN HEADER ON CLIENT in clientrequest.h *********/
enum API
{
    LOGIN,
    LOGOFF,
    COMMON_API,  // API calls below here are available to anyone
    VIEW_TASKS,
    VIEW_TASK,   // View Details about a specific task
    TA_API,      // API calls below here are available to TA
    VIEW_COURSES,// View assigned courses
    ADD_TASK,    // Add a task to a TA
    EDIT_TASK,
    EVALUATE_TASK,
    DELETE_TASK,
    VIEW_TAS_FOR_COURSE,
    VIEW_TAS,
    INSTRUCTOR_API,    // API calls below here are available to Instructor
    ADMINISTRATOR_API  // API calls below here until instructor are available + common...
};
/*****************************************************************************/


class QTcpSocket;
class QNetworkSession;

class ClientRequest : public QObject
{
    Q_OBJECT
    public:
        ClientRequest(QString ipAddress, qint16 portNum);
        ~ClientRequest();

        QString userLogin(QString username);
        QString userLogout();
        QString instructorViewCourses();
        QString instructorViewTasks();
        QString instructorViewTask(int taskID);
        QString instructorViewTAs();
        QString instructorViewTAsForCourse(int courseID);
        QString instructorAddTask(QString taUsername, QString taskName, QString goalsAndDuties);
        QString viewTasksForTA(QString TA);
        QString instructorEditTask(int taskID, QString taUsername, QString taskName, QString goalsAndDuties);
        QString instructorDeleteTask(int taskID);
        QString instructorSaveEvaluationData(int taskID, int rating, QString feedback);

signals:
        void generalError(QString error);
        void connectionRefusedError(QString error);
        void remoteHostClosedError(QString error);

    private slots:
        QString sendRequest(QString req);
        void displayError(QAbstractSocket::SocketError err);

    private:
        QTcpSocket *tcpSocket;
};

#endif // CLIENTREQUEST_H
