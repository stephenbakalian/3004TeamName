#include "datastoretests.h"

datastoretests::datastoretests(){
    i = 0;
    DataStore data;
}

//    DataStore data;
//    int i;



/******* USERES ********/

/******  Get all users from the datastore  *****/
bool datastoretests::getAllUsers(){
    std::vector<User*> users;
    int numUsers = data.getAllUsers(&users);
    for (int i = 0; i < numUsers; ++i) {
        qDebug() << QString::fromStdString(users.at(i)->getUsername());
        qDebug() << QString::fromStdString(users.at(i)->getPassword());
        qDebug() << users.at(i)->getUserType();
    }
    if(numUsers >= 0)
        return true;
    else
        return false;
}


/***** Get specific user from datastore   ******/
bool datastoretests::getSpecificUser(std::string username){
    User user;
    if(data.getUser(username, &user)){
        qDebug() << QString::fromStdString(user.getUsername()) << " was found";
        return true;
    }
    else{
        qDebug() << "no user";
        return false;
    }
}

/***** Add a User *****/
bool datastoretests::addUserTest(){
    User user("bob", "pass", ADMINISTRATOR_USER);
    return data.addUser(&user);
}
/**** Delete a User *****/
bool datastoretests::deleteUserTest(std::string username){
    return data.deleteUser(username);
}


/********* TASKS *********/

/**** Get all tasks *****/
bool datastoretests::getAllTasks(){
    std::vector<Task*> tasks;
    int numTasks = data.getAllTasks(&tasks);
    for (i = 0; i < numTasks; ++i) {
        qDebug() << tasks.at(i)->getTaskID();
        qDebug() << QString::fromStdString(tasks.at(i)->getTitle());
        qDebug() << QString::fromStdString(tasks.at(i)->getDutiesGoals());
        if(tasks.at(i)->getEvaluationData() != NULL){
            qDebug() << tasks.at(i)->getEvaluationData()->getEvaluation();
            qDebug() << QString::fromStdString(tasks.at(i)->getEvaluationData()->getFeedback());
        }
    }
    if (numTasks >= 0) {
        return true;
    }
    return false;
}



/******** Add Task   *********/
bool datastoretests::addTask(){
    Task task(5,"martin", "Shit for you to do...", "Do this Shit!!!");
    bool test1 = data.addTask(&task);

    EvaluationData evalData(10, "You so good...");

    Task task2(5, "martin", "addTaskToTA", "Do this task", &evalData);

    bool test2 = data.addTask(&task2);
    return test1 && test2;
}
/***** Edit Task *****/
bool datastoretests::editTask(){
    EvaluationData evalData(3, "Meh");
    Task task(1, "martin", "mo Stuff fo you", "Do this task", &evalData);

    if(data.editTask(&task)){
        qDebug() << "Edited";
        return true;
    }
    return false;
}
/**** Delete Task  ******/
bool datastoretests::deleteTask(){
    return data.deleteTask(7);
}


/******* COURSES  ********/


/***** Get all Courses ****/
bool datastoretests::getAllCourses(){
    std::vector<Course*> courses;
    int courseCount = data.getAllCourses(&courses);
    for (i = 0; i < courseCount; ++i) {
        qDebug() << QString::fromStdString(courses.at(i)->getCode());
        qDebug() << courses.at(i)->getSection();
        qDebug() << QString::fromStdString(courses.at(i)->getTerm());
        qDebug() << courses.at(i)->getYear();
        for (int j = 0; j < (int) courses.at(i)->getTaList().size(); ++j) {
            qDebug() << QString::fromStdString(courses.at(i)->getTaList().at(j));
        }
        qDebug() << QString::fromStdString(courses.at(i)->getInstructor());
    }
    if(courseCount < 0)
        return false;
    return true;
}
/***** Add a Course ******/
bool datastoretests::addCourse(){
    std::vector<std::string> TAs;
    TAs.push_back("Frank");
    TAs.push_back("Bob");
    TAs.push_back("Julia");

    Course course("COMP3005", 'A', "winter", 2012, TAs, "Mark", 1234567890);
    return data.addCourse(&course);
}

/*****  Edit a Course ****/
bool datastoretests::editCourse(){
    std::vector<std::string> TAs;
    TAs.push_back("Frank");
    TAs.push_back("Bob");
    TAs.push_back("Julia");
    Course oldCourse("COMP3005", 'A', "winter", 2012, TAs, "mark", 1234567890);
    if(data.addCourse(&oldCourse))
        qDebug() << "Course successfully added";
    Course newCourse("COMP3005", 'A', "winter", 2012, TAs, "luis", 1234567890);
    if(data.editCourse(&newCourse)){
        qDebug() << "Course Edited!";
        return true;
    }
    else
        return false;
}

/***** Delete a Course  ******/
bool datastoretests::deleteCourse(){
    std::vector<std::string> TAs;
    TAs.push_back("Frank");
    TAs.push_back("Bob");
    TAs.push_back("Julia");
    Course testCourse("COMP3005", 'A', "winter", 2012, TAs, "mark", 1234567890);
    if(data.addCourse(&testCourse))
        qDebug() << "Course successfully added";
    Course course("COMP3005", 'A', "winter", 2012);
    if(data.deleteCourse(course.getCourseID())){
        qDebug() << "Course Deleted!";
        return true;
    }
    else
        qDebug() << "WTF!!";
    return false;
}
