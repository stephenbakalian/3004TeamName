#include "instructorlogic.h"

InstructorLogic::InstructorLogic(DataStoreAPI *dsAPI){
    ds = dsAPI;
}

bool InstructorLogic::addTask(QString username, QString title, QString dutiesGoals){
    int taskID = abs(QUuid::createUuid().data1);
    Task task(taskID, username.toStdString(), title.toStdString(), dutiesGoals.toStdString());
    return ds->addTask(&task);
}

bool InstructorLogic::editTask(int taskID, QString username, QString title, QString dutiesGoals){
    Task task(taskID, username.toStdString(), title.toStdString(), dutiesGoals.toStdString());
    return ds->updateTask(&task);
}

bool InstructorLogic::evaluateTask(int taskID, int evaluation, QString feedback){
    Task task;
    ds->getTask(taskID, &task);
    EvaluationData eval(evaluation, feedback.toStdString());
    task.setEvaluationData(&eval);
    return ds->updateTask(&task);
}
bool InstructorLogic::deleteTask(int taskID){
    return ds->deleteTask(taskID);
}
