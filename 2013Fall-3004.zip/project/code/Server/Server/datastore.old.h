#ifndef DATASTORE_H
#define DATASTORE_H

#include <string>
#include <vector>
#include <QFile>
#include <QtXml/QXmlStreamReader>
#include <QtXml/QXmlStreamWriter>
#include <QDebug>
#include <iostream>
#include <QDir>

#include "user.h"
#include "task.h"
#include "course.h"

#define PATH    QCoreApplication::applicationDirPath()
#define USERS   "../Server/Users.xml"
#define COURSES "../Server/Courses.xml"
#define TASKS   "../Server/Tasks.xml"

class DataStore
{
public:
    DataStore();

    /*** User Database ***/

    // Return number of users on success, returns -1 on failure
    int getAllUsers(std::vector<User*> *users);

    // Return true on success, false on failure
    bool getUser(std::string username, User* user);

    // Returns true on success, false on failure
    bool addUser(User *user);

    // Returns true on success, false on failure
    bool editUser(User *user);

    // Returns true on success, false on failure
    bool deleteUser(std::string username);


    /***  Task Database ***/

    // Return number of tasks on success, returns -1 on failure
    int getAllTasks(std::vector<Task*> *tasks);

    // Returns -1 on failure
    bool getTask(int taskID, Task *task);

    // Return number of tasks on success, returns -1 on failure
    int getTasksForTA(std::string username, std::vector<Task*> *tasks);

    // Return number of tasks deleted on success, returns -1 on failure
    int deleteTasksForTA(std::string username);

    // return true on success, false on failure
    bool deleteTask(int taskID);

    // Add a single task to TA with username passed
    bool addTask(Task *task);

    // Modify the task that is passed. Return true on success, false onf failure
    bool editTask(Task *task);

    /***  Course Database ***/

    // Return number of courses on success, -1 on failure
    int getAllCourses(std::vector<Course*> *courses);

    // Return number of courses on success, -1 on failure
    int getCoursesForInstructor(std::string username, std::vector<Course*> *courses);

//    // Return true on success, false on failure
    bool addCourse(Course *course);

//    // Return true on success, false on failure
    bool editCourse(Course *oldCourse, Course *newCourse);

//    // Return true on success, false on failure
    bool deleteCourse(int courseID);

protected:

private:
    // Store passed in vector of Users, return number saved on success, -1 on failure
    int saveUsers(std::vector<User*> *users);
    // Store passed in vector of Tasks, return number saved on success, -1 on failure
    int saveTasks(std::vector<Task*> *tasks);
    // Store passed in vector of Courses, return number saved on success, -1 on failure
    int saveCourses(std::vector<Course*> *courses);
};

#endif // DATASTORE_H
