#include <QCoreApplication>
#include <iostream>

#include "server.h"
#include "controller.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Listen on the local interface for now
    QHostAddress serverAddress;
    QTcpSocket socket;
    socket.connectToHost("8.8.8.8", 53);
    if(socket.waitForConnected()){
      serverAddress = socket.localAddress();
      qDebug() << "Local IPv4 Address: " << serverAddress;
    }
    else{
      qWarning() << "Cannot determine local IPv4 Address";
      exit(-1);
    }
    qint16 serverPort = 60006;
    
    DataStore ds;

    Server* server = new Server(ds);
    if (!server->listen(serverAddress, serverPort)) {
        qDebug() << "Could not listen";
    }

    return a.exec();
}
