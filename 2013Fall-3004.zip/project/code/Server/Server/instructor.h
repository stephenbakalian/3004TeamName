#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H

#include <vector>

#include "user.h"
#include "course.h"

class Instructor : public User
{
public:
    Instructor(std::string username);
    Instructor(std::string username, std::string pass) : User(username, pass, INSTRUCTOR_USER){}

    std::vector<Course> getCourseList() const;
    void setCourseList(const std::vector<Course> &value);

private:
    std::vector<Course> courseList;
};

#endif // INSTRUCTOR_H
