#ifndef COURSE_H
#define COURSE_H

#include <vector>
#include <string>

#include"ta.h"

/*
 * TODO
 */

class Course
{
public:
    // de/constructor
    Course();
    Course(std::string code, char section, std::string term, int year);
    Course(std::string code, char section, std::string term, int year, std::vector<std::string> TAs, std::string instructorName, int id);
    ~Course();

    // getter, setter pairs
    std::string getCode() const;
    void setCode(const std::string &value);

    char getSection() const;
    void setSection(char value);

    std::string getTerm() const;
    void setTerm(const std::string &value);

    int getYear() const;
    void setYear(int value);

    std::vector<std::string> getTaList() const;
    void setTaList(const std::vector<std::string> &value);

    std::string getInstructor() const;
    void setInstructor(const std::string &value);

    int getCourseID() const;
    void setCourseID(int value);

private:
    // variables
    std::string               code;
    char                      section;
    std::string               term;
    int                       year;
    std::vector<std::string>  taList;
    std::string               instructor;
    int                       courseID;
};

#endif // COURSE_H
