#ifndef APPLOGIC_H
#define APPLOGIC_H

#include "commonlogic.h"
#include "instructorlogic.h"

/*
 * TODO
 */

class AppLogic
{
public:
    // de/constructor
    AppLogic();
    ~AppLogic();

    // getters and setters
    CommonLogic *getCommonLogic() const;
    void setCommonLogic(CommonLogic *value);

    InstructorLogic *getInstructorLogic() const;
    void setInstructorLogic(InstructorLogic *value);

private:
    // variables
    DataStoreAPI ds;
    CommonLogic *commonLogic;
    InstructorLogic *instructorLogic;
};

#endif // APPLOGIC_H
