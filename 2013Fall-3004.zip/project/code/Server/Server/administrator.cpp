#include "administrator.h"

// DE/CONSTRUCTOR
Administrator::Administrator()
{
}
