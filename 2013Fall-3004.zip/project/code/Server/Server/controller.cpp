#include "controller.h"

// DE/CONSTRUCTOR
Controller::Controller(DataStore ds, int socketDescriptor) : socketDescriptor(socketDescriptor), ds(ds)
{
    InstructorAPI instructorAPI;
}

Controller::~Controller()
{
}

// Partially handle requests by validating and handing off work to the Application Logic Layer via instructorAPI
void Controller::process()
{
    QTcpSocket tcpSocket;
    if (!tcpSocket.setSocketDescriptor(socketDescriptor))
    {
        emit error(QString("Socket error."));
        return;
    }
    // successful login
    qDebug("Client connected.");
    bool loggedIn = true;

    // Here we wait for them to talk to us.
    // First, the client has to log in. So, handle that.
    QString req;
    QStringList req_split;

    // user authentication has not been implemented, instead a static account is retrieved
    User* user = new User();
    //ds.getUser("claurendau", user);

    while(true)
    {
        // exit-loop if socket unconnected
        if (tcpSocket.state() == QAbstractSocket::UnconnectedState)
        {
            break;
        }

        // read incoming requests
        tcpSocket.waitForReadyRead(-1);
        req = QString(tcpSocket.readAll());
        req_split = req.split("\n");

//        qDebug(req_split[0].toStdString().c_str())

        // catch users that are no longer logged in
        if (!loggedIn)
        {
            if(req_split[0].toInt() > COMMON_API)
            {
                qDebug("No permissions");
                tcpSocket.write(QString("error\nnot logged in, cannot do command").toStdString().c_str());
                continue;
            }
        }
        else
        {
            // Permission check and error-handling
            switch (user->getUserType())
            {
            case TA_USER:
                if(req_split[0].toInt() > TA_API)
                {
                    qDebug("Incorrect permissions");
                    tcpSocket.write(QString("error\npermission not granted for this action").toStdString().c_str());
                }
                break;
            case INSTRUCTOR_USER:
                if(req_split[0].toInt() > INSTRUCTOR_API)
                {
                    qDebug("Incorrect permissions");
                    tcpSocket.write(QString("error\npermission not granted for this action").toStdString().c_str());
                }
                break;
            case ADMINISTRATOR_USER:
                if((req_split[0].toInt() < INSTRUCTOR_API) && (req_split[0].toInt() > TA_API))
                {
                    qDebug("Incorrect permissions");
                    tcpSocket.write(QString("error\npermission not granted for this action").toStdString().c_str());
                }
                break;
            default:
                qDebug("WHAT ARE YOU!?!");
            }
        }

        //Switch statement to handle incoming requests (login, logoff and all instructorAPI)
        qDebug() << req_split[0];
        switch (req_split[0].toInt())
        {
        case LOGIN:
            if (req_split.size() < 2)
            {
                qDebug("Not valid login attempt");
                tcpSocket.write(QString("error\nnot valid login attempt").toStdString().c_str());
            }
            // Look for the user in the datastore
            else if (!ds.getUser(req_split[1].toStdString(), user))
            {
                qDebug("User not found");
                tcpSocket.write(QString("error\nuser not found").toStdString().c_str());
            }
            else
            {
                qDebug("Logged in successfully");

                // send success response to client
                QStringList resp;
                resp << QString("success\nlogged in successfully");
                resp << QString::number(user->getUserType());
                tcpSocket.write(resp.join("\n").toStdString().c_str());
                loggedIn = true;
            }
            break;
        case LOGOFF:
            if(!loggedIn)
            {
                qDebug("Tried logging out while not logged in");
                loggedIn = false;
                tcpSocket.write(QString("error\nnot logged in").toStdString().c_str());
            }
            else
            {
                qDebug("Logging out");
                loggedIn = false;
                tcpSocket.write(QString("success").toStdString().c_str());
            }
            break;

            // handle all types of requests now that the user is logged in
        case VIEW_TASK:
            tcpSocket.write(instructorAPI.viewTask(&req_split).toStdString().c_str());
            break;
        case VIEW_TASKS:
            tcpSocket.write(instructorAPI.viewTasksForTA(&req_split).toStdString().c_str());
            break;
        case VIEW_COURSES:
            tcpSocket.write(instructorAPI.viewCourses(user->getUsername()).toStdString().c_str());
            break;
        case ADD_TASK:
            tcpSocket.write(instructorAPI.addTask(&req_split).toStdString().c_str());
            break;
        case EDIT_TASK:
            tcpSocket.write(instructorAPI.editTask(&req_split).toStdString().c_str());
            break;
        case EVALUATE_TASK:
            tcpSocket.write(instructorAPI.evaluateTask(&req_split).toStdString().c_str());
            break;
        case DELETE_TASK:
            qDebug() << req_split;
            tcpSocket.write(instructorAPI.deleteTask(&req_split).toStdString().c_str());
            break;
        case VIEW_TAS_FOR_COURSE:
            tcpSocket.write(instructorAPI.viewTAsForCourse(&req_split).toStdString().c_str());
            break;
        case VIEW_TAS:
//            tcpSocket.write(instructorAPI.viewTAs(user->getUsername()));
            break;

            // following cases aren't handled. Invalid client request
        case INSTRUCTOR_API:
        case ADMINISTRATOR_API:
        default:
            qDebug("WTF DID you DO?!?!?!");
        }
    }

    // The client did not disconnect from us.
    if (tcpSocket.state() == QAbstractSocket::ConnectedState)
    {
        tcpSocket.disconnectFromHost();
        tcpSocket.waitForDisconnected();
    }

    // clean up after client disconnects
    delete user;
    qDebug("Client disconnected.");
    emit finished();
}
