#ifndef TASK_H
#define TASK_H

#include "evaluationdata.h"

class Task
{
public:
    Task();
    Task(int taskID, std::string title, std::string dutiesGoals);
    Task(int taskID, std::string username, std::string title, std::string dutiesGoals);
    Task(int taskID, std::string username, std::string title, std::string dutiesGoals, EvaluationData *evaluationData);


    std::string getTitle() const;
    void setTitle(const std::string &value);

    std::string getDutiesGoals() const;
    void setDutiesGoals(const std::string &value);

    EvaluationData *getEvaluationData() const;
    void setEvaluationData(EvaluationData *value);

    int getTaskID() const;
    void setTaskID(int value);

    std::string getTaUsername() const;
    void setTaUsername(const std::string &value);

private:
    std::string     title;
    std::string     dutiesGoals;
    EvaluationData *evaluationData;
    int             taskID;
    std::string     taUsername;
};

#endif // TASK_H
