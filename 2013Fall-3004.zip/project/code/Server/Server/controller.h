#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <QObject>
#include <QtNetwork/QTcpSocket>
#include <QStringList>
#include <iostream>
#include <stdexcept>
#include <string>
#include <QtDebug>

#include "datastore.h"
#include "course.h"
#include "instructorapi.h"


/********* MUST MATCH ENUM IN HEADER ON CLIENT in clientrequest.h *********/
enum API
{
    LOGIN,
    LOGOFF,
    COMMON_API,  // API calls below here are available to anyone
    VIEW_TASKS,
    VIEW_TASK,   // View Details about a specific task
    TA_API,      // API calls below here are available to TA
    VIEW_COURSES,// View assigned courses
    ADD_TASK,    // Add a task to a TA
    EDIT_TASK,
    EVALUATE_TASK,
    DELETE_TASK,
    VIEW_TAS_FOR_COURSE,
    VIEW_TAS,
    INSTRUCTOR_API,    // API calls below here are available to Instructor
    ADMINISTRATOR_API  // API calls below here until instructor are available + common...
};
/*****************************************************************************/

/*
 * Partially handle requests by validating and handing off work to the Application Logic Layer via instructorAPI
 */

class Controller : public QObject
{
    Q_OBJECT

public:
    // de/constructor
    Controller(DataStore ds, int socketDescriptor);
    ~Controller();

public slots:
    //
    void process();

signals:
    //
    void error(QString err);
    void finished();

private:
    // variables
    int socketDescriptor;
    InstructorAPI instructorAPI;
    DataStore ds;
};

#endif // CONTROLLER_H
