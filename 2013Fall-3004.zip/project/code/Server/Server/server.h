#ifndef SERVER_H
#define SERVER_H

#include <QtNetwork/QTcpServer>
#include <QStringList>
#include <QThread>

#include "controller.h"
#include "datastore.h"

class Server : public QTcpServer
{
    public:
        Server(DataStore ds, QObject *parent = 0);

    protected:
        void incomingConnection(int socketDescriptor);

    private:
        QStringList users;
        DataStore ds;
};

#endif // SERVER_H
