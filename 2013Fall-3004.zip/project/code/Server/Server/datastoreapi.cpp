#include "datastoreapi.h"
#include "QString"

DataStoreAPI::DataStoreAPI()
{
    ds = new DataStore();
}
DataStoreAPI::~DataStoreAPI(){
    delete(ds);
}

// Create
bool DataStoreAPI::addUser(User* user){
    bool status = false;
    mutex.lock();
    status = ds->addUser(user);
    mutex.unlock();
    return status;
}
bool DataStoreAPI::addTask(Task* task){
    bool status = false;
    mutex.lock();
    status = ds->addTask(task);
    mutex.unlock();
    return status;
}
bool DataStoreAPI::addCourse(Course* course){
    bool status = false;
    mutex.lock();
    status = ds->addCourse(course);
    mutex.unlock();
    return status;
}

// Read
bool DataStoreAPI::getUser(QString username, User *user){
    bool status = false;
    mutex.lock();
    ds->getUser(username.toStdString(), user);
    mutex.unlock();
    return status;
}
int DataStoreAPI::getAllUsers(std::vector<User*> *users){
    int userCount= 0;
    mutex.lock();
    userCount = ds->getAllUsers(users);
    mutex.unlock();
    return userCount;
}
bool DataStoreAPI::getCourse(int courseID, Course* course){
    bool status = false;
    mutex.lock();
    status = ds->getCourse(courseID, course);
    mutex.unlock();
    return status;
}
int DataStoreAPI::getAllCourses(std::vector<Course*> *courses){
    int courseCount = 0;
    mutex.lock();
    courseCount = ds->getAllCourses(courses);
    mutex.unlock();
    return courseCount;
}
bool DataStoreAPI::getTask(int taskID, Task *task){
    bool status = false;
    mutex.lock();
    status = ds->getTask(taskID, task);
    mutex.unlock();
    return status;
}
int DataStoreAPI::getAllTasks(std::vector<Task*> *tasks){
    int taskCount = 0;
    mutex.lock();
    taskCount = ds->getAllTasks(tasks);
    mutex.unlock();
    return taskCount;
}
//    Update
bool DataStoreAPI::updateUser(User *user){
    bool status = false;
    mutex.lock();
    status = ds->editUser(user);
    mutex.unlock();
    return status;
}
bool DataStoreAPI::updateCourse(Course *course){
    bool status = false;
    mutex.lock();
    status = ds->editCourse(course);
    mutex.unlock();
    return status;
}
bool DataStoreAPI::updateTask(Task *task){
    bool status = false;
    mutex.lock();
    status = ds->editTask(task);
    mutex.unlock();
    return status;
}

//    Destroy
bool DataStoreAPI::deleteUser(QString username){
    bool status = false;
    mutex.lock();
    status = ds->deleteUser(username.toStdString());
    mutex.unlock();
    return status;
}
bool DataStoreAPI::deleteCourse(int courseID){
    bool status = false;
    mutex.lock();
    status = ds->deleteCourse(courseID);
    mutex.unlock();
    return status;
}
bool DataStoreAPI::deleteTask(int taskID){
    bool status = false;
    mutex.lock();
    status = ds->deleteTask(taskID);
    mutex.unlock();
    return status;
}
