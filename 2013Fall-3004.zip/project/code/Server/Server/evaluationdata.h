#ifndef EVALUATIONDATA_H
#define EVALUATIONDATA_H

#include <string>

class EvaluationData
{
public:
    EvaluationData();
    EvaluationData(int evaluation, std::string feedback);

    int getEvaluation() const;
    void setEvaluation(int value);

    std::string getFeedback() const;
    void setFeedback(const std::string &value);

private:
    int         evaluation;
    std::string feedback;
};

#endif // EVALUATIONDATA_H
