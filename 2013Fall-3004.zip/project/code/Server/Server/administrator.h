#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include "user.h"

/*
 * TODO
 */

class Administrator : public User
{
public:
    // de/constructor
    Administrator();
    Administrator(std::string username, std::string pass) : User(username, pass, ADMINISTRATOR_USER){}
};

#endif // ADMINISTRATOR_H
