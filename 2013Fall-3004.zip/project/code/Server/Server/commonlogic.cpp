#include "commonlogic.h"

// DE/CONSTRUCTOR
CommonLogic::CommonLogic(DataStoreAPI *dsAPI)
{
    ds = dsAPI;
}

CommonLogic::~CommonLogic()
{
}

// GETTERS - retrieve the corresponding data from the datastore, pushing to the arguments passed by reference. All but one returns the size of retrieved data //
int CommonLogic::getCoursesForUser(QString username, std::vector<Course*> *courses)
{
    std::vector<Course*> tempList;
    int courseCount = ds->getAllCourses(&tempList);

    for (int i = 0; i < courseCount; ++i)
    {
        if(tempList.at(i)->getInstructor() == username.toStdString())
        {
            courses->push_back(tempList.at(i));
        }
    }
    return (int) courses->size();
}

int CommonLogic::getTasksForUser(QString username, std::vector<Task*> *tasks)
{
    std::vector<Task*> tempList;
    int taskCount = ds->getAllTasks(&tempList);
    for (int i = 0; i < taskCount; ++i)
    {
        if(tempList.at(i)->getTaUsername() == username.toStdString())
        {
            tasks->push_back(tempList.at(i));
        }
    }
    return (int) tasks->size();
}

// returns a datastore function call that returns a bool
bool CommonLogic::getTask(int taskID, Task* task)
{
    return ds->getTask(taskID, task);
}

int CommonLogic::getTAsForCourse(int courseID, std::vector<QString> *taList)
{
    Course course;
    if(ds->getCourse(courseID, &course))
    {
        for (int i = 0; i < (int) course.getTaList().size(); ++i)
        {
            taList->push_back(QString::fromStdString(course.getTaList().at(i)));
        }
    }
    else
    {
        qDebug("Course couldn't be found");
    }
    return taList->size();
}
