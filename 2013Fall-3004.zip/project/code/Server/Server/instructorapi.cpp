#include "instructorapi.h"

InstructorAPI::InstructorAPI()
{
    appLogic = new AppLogic();
}
InstructorAPI::~InstructorAPI(){
    delete(appLogic);
}
QString InstructorAPI::viewTask(QStringList *input){
    if ((*input).size() < 2) {
        return (QString) QString("error\nincorrect number of parameters").toStdString().c_str();
    }
    QStringList resp;
    Task task;
    if(!appLogic->getCommonLogic()->getTask((*input)[1].toInt(), &task)){
        return (QString) QString("error\ntask not found").toStdString().c_str();
    }
    resp    << "success"
            << QString::number(task.getTaskID())
            << QString(task.getTitle().c_str())
            << QString(task.getTaUsername().c_str())
            << QString(QByteArray(task.getDutiesGoals().c_str()).toBase64());
    if(task.getEvaluationData() != NULL){
        resp << QString::number(task.getEvaluationData()->getEvaluation())
             << QString(QByteArray(task.getEvaluationData()->getFeedback().c_str()).toBase64());
    }
    return (QString) resp.join("\n").toStdString().c_str();
}
QString InstructorAPI::viewCourses(std::string username){
    int courseCount = 0;
    QStringList resp;
    std::vector<Course*> courses;
    courseCount = appLogic->getCommonLogic()->getCoursesForUser(QString::fromStdString(username), &courses);
    if(courseCount >= 0){
        QStringList courseInfo;
        for (int i = 0; i < courseCount; ++i) {
            courseInfo      << QString::fromStdString(courses.at(i)->getCode())
                            << QChar(courses.at(i)->getSection())
                            << QString::fromStdString(courses.at(i)->getTerm())
                            << QString::number(courses.at(i)->getYear())
                            << QString::number(courses.at(i)->getCourseID());
            resp.append(courseInfo.join(QString(",\t")));
            courseInfo.clear();
        }
        resp.push_front(QString("success"));
        return (QString) resp.join("\n").toStdString().c_str();
    }
    else{
        return (QString) QString("error\nFailed to retreive courses for user.").toStdString().c_str();
    }
}

QString InstructorAPI::addTask(QStringList *input){
    if((*input).size() != 4){
        return (QString) QString("error\nincorrect number of parameters").toStdString().c_str();
    }
    if(appLogic->getInstructorLogic()->addTask((*input)[1], (*input)[2],
            QString(QByteArray::fromBase64((*input)[3].toStdString().c_str())))){
        return (QString) QString("success\ntask successfully added").toStdString().c_str();
    }
    else{
        return (QString) QString("error\ntask could not be added").toStdString().c_str();
    }
}
QString InstructorAPI::editTask(QStringList *input){
    if((*input).size() != 5){
        return (QString) QString("error\nincorrect number of parameters").toStdString().c_str();
    }
    if(appLogic->getInstructorLogic()->editTask((*input)[1].toInt(), (*input)[2], (*input)[3],
            QString(QByteArray::fromBase64((*input)[4].toStdString().c_str())))){
        return (QString) QString("success\ntask successfully modified").toStdString().c_str();
    }
    else{
        return (QString) QString("error\ntask could not be modified").toStdString().c_str();
    }
}
QString InstructorAPI::evaluateTask(QStringList *input){
    if((*input).size() != 4){
        return (QString) QString("error\nincorrect number of parameters").toStdString().c_str();
    }
    if(!appLogic->getInstructorLogic()->evaluateTask((*input)[1].toInt(), (*input)[2].toInt(),
                QString(QByteArray::fromBase64((*input)[3].toStdString().c_str())))){
        return (QString) QString("error\nunable to evaluate task").toStdString().c_str();
    }
    else{
        return (QString) QString("success\nsuccessfully evaluated task").toStdString().c_str();
    }
}
QString InstructorAPI::viewTasksForTA(QStringList *input){
    if((*input).size() != 2){
        return (QString) QString("error\nincorrect number of parameters").toStdString().c_str();
    }
    std::vector<Task *> tasks;
    if(appLogic->getCommonLogic()->getTasksForUser((*input)[1], &tasks) < 0){
        return (QString) QString("error\nunable to retreive tasks for ta").toStdString().c_str();
    }
    QStringList taskInfo;
    QStringList resp;
    for (int i = 0; i < (int) tasks.size(); ++i) {
        taskInfo << QString::number(tasks.at(i)->getTaskID())
                 << QString(tasks.at(i)->getTitle().c_str())
                 << QString(tasks.at(i)->getTaUsername().c_str())
                 << QString(QByteArray(tasks.at(i)->getDutiesGoals().c_str()).toBase64());
        if(tasks.at(i)->getEvaluationData() != NULL){
            taskInfo <<QString::number(tasks.at(i)->getEvaluationData()->getEvaluation())
                    << QString(QByteArray(tasks.at(i)->getEvaluationData()->getFeedback().c_str()).toBase64());
        }
        resp.append(taskInfo.join(QString(",\t")));
        taskInfo.clear();
    }
    resp.push_front(QString("success"));
    return (QString) resp.join("\n").toStdString().c_str();
}
QString InstructorAPI::deleteTask(QStringList *input){
    if((*input).size() != 2){
        return (QString) QString("error\nincorrect number of parameters").toStdString().c_str();
    }
    if(appLogic->getInstructorLogic()->deleteTask((*input)[1].toInt())){
        return (QString) QString("success\nsuccessfully deleted task").toStdString().c_str();
    }
    return (QString) QString("error\nunable to delete task").toStdString().c_str();
}
QString InstructorAPI::viewTAsForCourse(QStringList *input){
    if((*input).size() != 2){
        return (QString) QString("error\nincorrect number of parameters, please just pass the courseID").toStdString().c_str();
    }
    std::vector<QString> TAs;
    int numTAs = 0;
    numTAs = appLogic->getCommonLogic()->getTAsForCourse((*input)[1].toInt(), &TAs);
    QStringList resp;
    if(numTAs >= 0){
        for (int i = 0; i < numTAs; ++i) {
            resp << TAs.at(i);
        }
        resp.push_front(QString("success"));
        return (QString) resp.join("\n").toStdString().c_str();
    }
    else{
        return (QString) QString("error\nunable to retrive courses for user").toStdString().c_str();
    }
    return (QString) QString("error\nunable to retrive courses for user").toStdString().c_str();
}
