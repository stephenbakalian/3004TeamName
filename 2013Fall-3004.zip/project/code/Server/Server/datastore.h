#ifndef DATASTORE_H
#define DATASTORE_H

#include <string>
#include <vector>
#include <QFile>
#include <QtXml/QXmlStreamReader>
#include <QtXml/QXmlStreamWriter>
#include <QDebug>
#include <iostream>
#include <QDir>

#include "user.h"
#include "task.h"
#include "course.h"

// used to connect the datastore to each xml database file
#define PATH    QCoreApplication::applicationDirPath()
#define USERS   "../Server/Users.xml"
#define COURSES "../Server/Courses.xml"
#define TASKS   "../Server/Tasks.xml"

/*
 * TODO
 */

class DataStore
{
public:
    // de/constructor
    DataStore();
    ~DataStore();

    /*
    ** User Database **
    */
    // Returns true on success, false on failure
    bool addUser(User *user);

    // Return true on success, false on failure
    bool getUser(std::string username, User* user);

    // Return number of users on success, returns -1 on failure
    int getAllUsers(std::vector<User*> *users);

    // Returns true on success, false on failure
    bool editUser(User *user);

    // Returns true on success, false on failure
    bool deleteUser(std::string username);


    /*
    **  Task Database **
    */
    // Add a single task to TA with username passed
    bool addTask(Task *task);

    // Returns false on failure
    bool getTask(int taskID, Task *task);

    // Return number of tasks on success, returns -1 on failure
    int getAllTasks(std::vector<Task*> *tasks);

    // Modify the task that is passed. Return true on success, false onf failure
    bool editTask(Task *task);

    // return true on success, false on failure
    bool deleteTask(int taskID);


    /*
    **  Course Database **
    */
    // Return true on success, false on failure
    bool addCourse(Course *course);

    // Return true on success, false on failure
    bool getCourse(int courseID, Course *course);

    // Return number of courses on success, -1 on failure
    int getAllCourses(std::vector<Course*> *courses);

   // Return true on success, false on failure
    bool editCourse(Course *course);

   // Return true on success, false on failure
    bool deleteCourse(int courseID);

private:
    // Store passed in vector of Users, return number saved on success, -1 on failure
    int saveUsers(std::vector<User*> *users);
    // Store passed in vector of Tasks, return number saved on success, -1 on failure
    int saveTasks(std::vector<Task*> *tasks);
    // Store passed in vector of Courses, return number saved on success, -1 on failure
    int saveCourses(std::vector<Course*> *courses);
};

#endif // DATASTORE_H
