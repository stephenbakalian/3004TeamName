#include "evaluationdata.h"

EvaluationData::EvaluationData()
{
}
EvaluationData::EvaluationData(int evaluation, std::string feedback)
{
    setEvaluation(evaluation);
    setFeedback(feedback);
}

int EvaluationData::getEvaluation() const
{
    return evaluation;
}

void EvaluationData::setEvaluation(int value)
{
    evaluation = value;
}
std::string EvaluationData::getFeedback() const
{
    return feedback;
}

void EvaluationData::setFeedback(const std::string &value)
{
    feedback = value;
}


