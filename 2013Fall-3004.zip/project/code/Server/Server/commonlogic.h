#ifndef COMMONLOGIC_H
#define COMMONLOGIC_H

#include <vector>
#include "datastoreapi.h"

/*
 * TODO
 */

class CommonLogic
{
public:
    // de/constructor
    CommonLogic(DataStoreAPI *dsAPI);
    ~CommonLogic();

    // getters
    int getCoursesForUser(QString username, std::vector<Course*> *courses);
    int getTasksForUser(QString username, std::vector<Task*> *tasks);
    bool getTask(int taskID, Task* task);
    int getTAsForCourse(int courseID, std::vector<QString> *taList);
    
private:
    // variables
    DataStoreAPI *ds;
};

#endif // COMMONLOGIC_H
