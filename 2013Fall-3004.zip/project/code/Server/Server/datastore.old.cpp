#include "datastore.h"

DataStore::DataStore()
{

}

/*** Users ***/

int DataStore::getAllUsers(std::vector<User*> *users){
    std::string username = "NONE", password="NONE";
    UserType    userType = TA_USER;

    QFile *file = new QFile(USERS);
    if (!file->open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Can't open file!";
        return -1; // Shit broke
    }
    QXmlStreamReader xml(file);
    while(!xml.atEnd() && !xml.hasError()) {
        QXmlStreamReader::TokenType token = xml.readNext();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            continue;
        }
        //If token is StartElement - read it
        if(token == QXmlStreamReader::StartElement) {
            if(xml.name() == "Users") // Wrapper node, continue
                continue;
            if (xml.name() == "user") {
                foreach(const QXmlStreamAttribute &attr, xml.attributes()) {
                    if (attr.name().toString() == "username") {
                        username = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(username);
                    }
                    else if (attr.name().toString() == "password") {
                        password = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(password);
                    }
                    else if (attr.name().toString() == "user_type") {
                        userType = (UserType) attr.value().at(0).digitValue();
//                        qDebug() << userType;
                    }
                }
                users->push_back(new User(username, password, userType));
            }
            else{
                qDebug() << "Our XML data is fucked up...";
                file->close();
                return -1;
            }
        }
    }
    if (xml.hasError()) {
        qDebug() << "xml.hasError()";
        file->close();
        return -1;
    }
    file->close();
    return users->size();
}

// Get the user with this information
bool DataStore::getUser(std::string username, User *user){
    std::vector<User*> users;
    int i = getAllUsers(&users);
    bool found = false;
//    qDebug() << QString::fromStdString(username);
    for (i--; i >= 0 && !found; i--) {
//        qDebug() << QString::fromStdString(users.at(i)->getUsername() );
        if(users.at(i)->getUsername() == username){
            found = true;
//            qDebug() << QString::fromStdString(users.at(i)->getUsername());
            user->setUsername(users.at(i)->getUsername());
            user->setPassword(users.at(i)->getPassword());
            user->setUserType(users.at(i)->getUserType());
        }
    }
    return found;
}

// Admin Function
bool DataStore::addUser(User *user){
    std::vector<User*> users;
    int i = getAllUsers(&users);
    users.push_back(user);
    if(saveUsers(&users) == i+1)
        return true;
    else
        return false;
}

//Admin Function
bool DataStore::deleteUser(std::string username){
    bool found = false;
    int index;
    std::vector<User*> users;
    getAllUsers(&users);
//    qDebug() << username;
    for (index = users.size() - 1; index >= 0 && !found; index--) {
        if(users.at(index)->getUsername() == username){
//            qDebug() << index;
            found = true;
        }
    }
    if(found){
        users.erase(users.begin() + index+1);
        saveUsers(&users);
    }
    return false;
}

int DataStore::saveUsers(std::vector<User*> *users){
    QFile *file = new QFile(USERS);
    if (!file->open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Can't open file!";
        return -1; // Shit broke
    }
    QXmlStreamWriter xml(file);
    xml.setAutoFormatting(true);
    xml.writeStartDocument();
    xml.writeStartElement("Users");
    for (int i = 0; i < (int) users->size(); ++i) {
        xml.writeStartElement("user");
        xml.writeAttribute("username", QString::fromStdString(users->at(i)->getUsername()));
        xml.writeAttribute("password", QString::fromStdString(users->at(i)->getPassword()));
        xml.writeAttribute("user_type", QString::number(users->at(i)->getUserType()));
        xml.writeEndElement(); // user
    }
    xml.writeEndElement(); // Users
    file->close();
    return users->size();
}

/*** Tasks ***/

// Admin function
int DataStore::getAllTasks(std::vector<Task*> *tasks){
    std::string username, title, dutiesGoals, feedback;
    int id = 0, evaluation = - 1;

    QFile *file = new QFile(TASKS);
    if (!file->open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Can't open file!";
        return -1; // Shit broke
    }
    QXmlStreamReader xml(file);
    while(!xml.atEnd() && !xml.hasError()) {
        QXmlStreamReader::TokenType token = xml.readNext();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            continue;
        }
        //If token is StartElement - read it
        if(token == QXmlStreamReader::StartElement) {
            if(xml.name() == "Tasks") // Wrapper node, continue
                continue;
//            qDebug() << xml.name();
            evaluation = -1;
            if (xml.name() == "task") {
                foreach(const QXmlStreamAttribute &attr, xml.attributes()) {
                    if (attr.name().toString() == "id") {
                        id = atoi(attr.value().toString().toStdString().c_str());
//                        qDebug() << id;
                    }
                    else if (attr.name().toString() == "ta_username") {
                        username = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(username);
                    }
                    else if (attr.name().toString() == "title") {
                        title = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(title);
                    }
                }
                xml.readNextStartElement();
                if(xml.name() == "dutiesGoals"){
                    dutiesGoals = xml.readElementText().toStdString();
//                    qDebug() << QString::fromStdString(dutiesGoals);
                }
                else{
                    qDebug() << "dutiesGoals XML Data Fucked";
                    file->close();
                    return -1;
                }
                xml.readNext();
                if(xml.readNextStartElement ()){
                    if(xml.name() == "evalData"){
                        evaluation = atoi(xml.attributes().at(0).value().toString().toStdString().c_str());
//                        qDebug() << evaluation;
                    }
                    if(xml.readNextStartElement ()){
                        if(xml.name() == "feedback"){
                            feedback = xml.readElementText().toStdString();
//                            qDebug() << QString::fromStdString(feedback);
                        }
                    }
                }
                if(evaluation > 0){
                    EvaluationData *eval = new EvaluationData(evaluation, feedback);
                    tasks->push_back(new Task(id, username, title, dutiesGoals, eval));
                }
                else{
                    tasks->push_back(new Task(id, username, title, dutiesGoals));
                }
            }
            else{
                qDebug() << "Our XML data is fucked up...";
                file->close();
                return -1;
            }
        }
    }
    if (xml.hasError()) {
        qDebug() << "xml.hasError()";
        file->close();
        return -1;
    }
    file->close();
    return tasks->size();
}

bool DataStore::getTask(int taskID, Task *task){
    int index;
    std::vector<Task*> tasks;
    getAllTasks(&tasks);
    bool found = false;
    for (index = tasks.size() - 1; index >= 0 && !found; index--) {
        if(tasks.at(index)->getTaskID() == taskID){
            found = true;
            break;
        }
    }

    if(found){
        task->setTaskID(tasks.at(index)->getTaskID());
        task->setTaUsername(tasks.at(index)->getTaUsername());
        task->setTitle(tasks.at(index)->getTitle());
        task->setDutiesGoals(tasks.at(index)->getDutiesGoals());
        task->setEvaluationData(tasks.at(index)->getEvaluationData());
        return true;
    }
    return false;
}

int DataStore::getTasksForTA(std::string username, std::vector<Task*> *tasks){
    int i = getAllTasks(tasks);
//    qDebug() << i;
    for (i--; i >= 0 ; i--) {
//        qDebug() << QString::fromStdString(tasks->at(i)->getTaUsername() );
        if(tasks->at(i)->getTaUsername() != username){
            tasks->erase(tasks->begin()+i);
        }
    }
    return tasks->size();
}

int DataStore::deleteTasksForTA(std::string username){
    int i;
    std::vector<Task*> tasks;
    getTasksForTA(username, &tasks);
//    qDebug() << tasks.size();
    for (i = 0; i < (int) tasks.size(); ++i) {
        deleteTask(tasks.at(i)->getTaskID());
    }
    return i;
}

bool DataStore::deleteTask(int taskID){
    bool found = false;
    int index;
    std::vector<Task*> tasks;
    getAllTasks(&tasks);
//    qDebug() << taskID;
    for (index = tasks.size() - 1; index >= 0 && !found; index--) {
        if(tasks.at(index)->getTaskID() == taskID){
//            qDebug() << index;
            found = true;
        }
    }
    if(found){
        tasks.erase(tasks.begin()+index+1);
        return saveTasks(&tasks);
    }
    return false;
}
bool DataStore::addTask(Task *task){
    std::vector<Task*> tasks;
    int i = getAllTasks(&tasks);
    tasks.push_back(task);
    if(saveTasks(&tasks) == i+1)
        return true;
    else
        return false;
}

bool DataStore::editTask(Task *task){
    bool found = false;
    int index;
    std::vector<Task*> tasks;
    getAllTasks(&tasks);
//    qDebug() << task->getTaskID();
    for (index = tasks.size() - 1; index >= 0 && !found; index--) {
//        qDebug() << tasks.at(index)->getTaskID();
        if(tasks.at(index)->getTaskID() == task->getTaskID()){
//            qDebug() << index;
            task->setTaUsername(tasks.at(index)->getTaUsername());
            if(task->getEvaluationData() == NULL){
                task->setEvaluationData(tasks.at(index)->getEvaluationData());
            }
            found = true;
        }
    }
    if(found){
        tasks.erase(tasks.begin() + index + 1);
        tasks.push_back(task);
        saveTasks(&tasks);
        return true;
    }
    else{
        qDebug() << "Modified task not found";
        return false;
    }
}

int DataStore::saveTasks(std::vector<Task*> *tasks){
    QFile *file = new QFile(TASKS);
    if (!file->open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Can't open file!";
        return -1; // Shit broke
    }
    QXmlStreamWriter xml(file);
    xml.setAutoFormatting(true);
    xml.writeStartDocument();
    xml.writeStartElement("Tasks");
    for (int i = 0; i < (int) tasks->size(); ++i) {
        xml.writeStartElement("task");
        xml.writeAttribute("id", QString::number(tasks->at(i)->getTaskID()));
        xml.writeAttribute("ta_username", QString::fromStdString(tasks->at(i)->getTaUsername()));
        xml.writeAttribute("title", QString::fromStdString(tasks->at(i)->getTitle()));
        xml.writeTextElement("dutiesGoals", QString::fromStdString(tasks->at(i)->getDutiesGoals()));
        if(tasks->at(i)->getEvaluationData() != NULL){
            xml.writeStartElement("evalData");
            xml.writeAttribute("evaluation", QString::number(tasks->at(i)->getEvaluationData()->getEvaluation()));
            xml.writeTextElement("feedback", QString::fromStdString(tasks->at(i)->getEvaluationData()->getFeedback()));
            xml.writeEndElement(); // evalData
        }
        xml.writeEndElement(); // task
    }
    xml.writeEndElement(); // Tasks
    file->close();
    return tasks->size();
}

/*** Courses ***/

// Admin Function
int DataStore::getAllCourses(std::vector<Course*> *courses){
    std::string code = "NONE", term = "NONE", instructor="NONE";
    int year = 0;
    char section = 0;
    std::vector<std::string> *TAs;

    QFile *file = new QFile(COURSES);
    if (!file->open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Can't open file!";
        return -1; // Shit broke
    }
    QXmlStreamReader xml(file);
    while(!xml.atEnd() && !xml.hasError()) {
        QXmlStreamReader::TokenType token = xml.readNext();
        //If token is just StartDocument - go to next
        if(token == QXmlStreamReader::StartDocument) {
            continue;
        }
        //If token is StartElement - read it
        if(token == QXmlStreamReader::StartElement) {
            if(xml.name() == "Courses") // Wrapper node, continue
                continue;
//            qDebug() << xml.name();
            TAs = new std::vector<std::string>();
            if (xml.name() == "course") {
                foreach(const QXmlStreamAttribute &attr, xml.attributes()) {
                    if (attr.name().toString() == "code") {
                        code = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(code);
                    }
                    else if (attr.name().toString() == "section") {
                        section = attr.value().toString().toStdString().at(0);
//                        qDebug() << section;
                    }
                    else if (attr.name().toString() == "term") {
                        term = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(term);
                    }
                    else if (attr.name().toString() == "year") {
                        year = atoi(attr.value().toString().toStdString().c_str());
//                        qDebug() << year;
                    }
                    else if (attr.name().toString() == "instructor") {
                        instructor = attr.value().toString().toStdString();
//                        qDebug() << QString::fromStdString(instructor);
                    }
                }
                xml.readNextStartElement();
                if (xml.name() != "TAs") {
                    qDebug() << "Courses XML document broken!!!";
                    file->close();
                    return -1;
                }
                while(xml.readNextStartElement())
                {
                    TAs->push_back(xml.readElementText().toStdString());
//                    qDebug() << QString::fromStdString(TAs.back());
                }
                courses->push_back(new Course(code, section, term, year, *TAs, instructor));
            }
            else{
                qDebug() << "Our XML data is fucked up...";
                file->close();
                return -1;
            }
        }
    }
    if (xml.hasError()) {
        qDebug() << "xml.hasError()";
        file->close();
        return -1;
    }
    file->close();
    return courses->size();
}

int DataStore::getCoursesForInstructor(std::string username, std::vector<Course*> *courses){
    int i = getAllCourses(courses);
    for (i-=1; i >= 0 ; i--) {
        if(courses->at(i)->getInstructor() != username){
            courses->erase(courses->begin()+i);
        }
    }
    return courses->size();
}
// Admin Function
bool DataStore::addCourse(Course *course){
    std::vector<Course*> courses;
    int i = getAllCourses(&courses);
    courses.push_back(course);
    if(saveCourses(&courses) == i+1)
        return true;
    else
        return false;
}
//Admin Function
bool DataStore::editCourse(Course *oldCourse, Course *newCourse){
    if(deleteCourse(oldCourse))
        return addCourse(newCourse);
    else
        return false;
}

// Admin function
bool DataStore::deleteCourse(Course *course){
    bool found = false;
    int index;
    std::vector<Course*> courses;
    getAllCourses(&courses);

//    qDebug() << QString::fromStdString(course->getCode());
//    qDebug() << QString(QChar(course->getSection()));
//    qDebug() << QString::fromStdString(course->getTerm());
//    qDebug() << course->getYear();

    for (index = courses.size() - 1; index >= 0 && !found; index--) {

//        qDebug() << QString::fromStdString(courses.at(index)->getCode());
//        qDebug() << QString(QChar(courses.at(index)->getSection()));
//        qDebug() << QString::fromStdString(courses.at(index)->getTerm());
//        qDebug() << courses.at(index)->getYear();

        if(courses.at(index)->getCode() == course->getCode()
                && courses.at(index)->getSection() == course->getSection()
                && courses.at(index)->getTerm() == course->getTerm()
                && courses.at(index)->getYear() == course->getYear()
                ){
//            qDebug() << index;
            found = true;
        }
    }
    if(found){
        courses.erase(courses.begin()+index+1);
        return saveCourses(&courses);
    }
    return false;
}

int DataStore::saveCourses(std::vector<Course*> *courses){
    QFile *file = new QFile(COURSES);
    if (!file->open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Can't open file!";
        return -1; // Shit broke
    }
    QXmlStreamWriter xml(file);
    xml.setAutoFormatting(true);
    xml.writeStartDocument();
    xml.writeStartElement("Courses");
    for (int i = 0; i < (int) courses->size(); ++i) {
        xml.writeStartElement("course");
        xml.writeAttribute("code", QString::fromStdString(courses->at(i)->getCode()));
        xml.writeAttribute("section", QString(QChar(courses->at(i)->getSection())));
        xml.writeAttribute("term", QString::fromStdString(courses->at(i)->getTerm()));
        xml.writeAttribute("year", QString::number(courses->at(i)->getYear()));
        xml.writeAttribute("instructor", QString::fromStdString(courses->at(i)->getInstructor()));
        xml.writeStartElement("TAs");
        for (int j = 0; j < (int) courses->at(i)->getTaList().size(); ++j) {
            xml.writeTextElement("TA", QString::fromStdString(courses->at(i)->getTaList().at(j)));
        }
        xml.writeEndElement(); // TAs
        xml.writeEndElement(); // course
    }
    xml.writeEndElement(); // Courses
    file->close();
    return courses->size();
}



