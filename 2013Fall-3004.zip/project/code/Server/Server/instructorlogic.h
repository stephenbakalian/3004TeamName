#ifndef INSTRUCTORLOGIC_H
#define INSTRUCTORLOGIC_H

#include <QString>
#include <QUuid>
#include "datastoreapi.h"

class InstructorLogic
{
public:
    InstructorLogic(DataStoreAPI *dsAPI);
    bool addTask(QString username, QString title, QString dutiesGoals);
    bool editTask(int taskID, QString username, QString title, QString dutiesGoals);
    bool evaluateTask(int taskID, int evaluation, QString feedback);
    bool deleteTask(int taskID);

private:
    DataStoreAPI *ds;
};

#endif // INSTRUCTORLOGIC_H
