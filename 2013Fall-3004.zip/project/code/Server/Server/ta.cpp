#include "ta.h"

std::vector<Task> TA::getTaskList() const
{
    return taskList;
}

void TA::setTaskList(const std::vector<Task> &value)
{
    taskList = value;
}

