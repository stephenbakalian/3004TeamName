#include "instructor.h"

std::vector<Course> Instructor::getCourseList() const
{
    return courseList;
}

void Instructor::setCourseList(const std::vector<Course> &value)
{
    courseList = value;
}
