#include "server.h"
#include <iostream>


Server::Server(DataStore ds, QObject *parent) : QTcpServer(parent), ds(ds)
{
}

void Server::incomingConnection(int socketDescriptor)
{
    Controller* controller = new Controller(ds, socketDescriptor);
    QThread* controlThread = new QThread();
    controller->moveToThread(controlThread);

    connect(controlThread, SIGNAL(started()), controller, SLOT(process()));
    connect(controller, SIGNAL(finished()), controlThread, SLOT(quit()));
    connect(controller, SIGNAL(finished()), controller, SLOT(deleteLater()));
    connect(controlThread, SIGNAL(finished()), controlThread, SLOT(deleteLater()));
    controlThread->start();
}
