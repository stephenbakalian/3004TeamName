#ifndef TA_H
#define TA_H

#include <vector>

#include "user.h"
#include "task.h"

class TA : public User
{
public:
    TA(std::string username);
    TA(std::string username, std::string pass) : User(username, pass, TA_USER){}


    std::vector<Task> getTaskList() const;
    void setTaskList(const std::vector<Task> &value);

private:
    std::vector<Task> taskList;
};

#endif // TA_H
