#include "user.h"

User::User()
{
    setUsername("NoUsername");
    setPassword("NoPasswordSet");
}

User::User(std::string name, std::string pass, UserType type)
{
    setUsername(name);
    setPassword(pass);
    setUserType(type);
}
User::~User(){

}

std::string User::getUsername() const
{
    return username;
}

void User::setUsername(const std::string &value)
{
    username = value;
}
std::string User::getPassword() const
{
    return password;
}

void User::setPassword(const std::string &value)
{
    password = value;
}

UserType User::getUserType() const
{
    return userType;
}

void User::setUserType(const UserType &value)
{
    userType = value;
}



