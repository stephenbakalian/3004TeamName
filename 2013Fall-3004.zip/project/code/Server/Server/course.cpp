#include "course.h"

// DE/CONSTRUCTOR
Course::Course()
{
}

Course::Course(std::string code, char section, std::string term, int year)
{
    setCode(code);
    setSection(section);
    setTerm(term);
    setYear(year);
}

Course::Course(std::string code, char section, std::string term,
       int year, std::vector<std::string>  taList, std::string instructor, int id)
{
    setCode(code);
    setSection(section);
    setTerm(term);
    setYear(year);
    setTaList(taList);
    setInstructor(instructor);
    setCourseID(id);
}

Course::~Course()
{
}

// GETTER, SETTER PAIRS
std::string Course::getCode() const
{
    return code;
}

void Course::setCode(const std::string &value)
{
    code = value;
}

char Course::getSection() const
{
    return section;
}

void Course::setSection(char value)
{
    section = value;
}

std::string Course::getTerm() const
{
    return term;
}

void Course::setTerm(const std::string &value)
{
    term = value;
}

int Course::getYear() const
{
    return year;
}

void Course::setYear(int value)
{
    year = value;
}

std::vector<std::string> Course::getTaList() const
{
    return taList;
}

void Course::setTaList(const std::vector<std::string> &value)
{
    taList = value;
}

std::string Course::getInstructor() const
{
    return instructor;
}

void Course::setInstructor(const std::string &value)
{
    instructor = value;
}

int Course::getCourseID() const
{
    return courseID;
}

void Course::setCourseID(int value)
{
    courseID = value;
}
