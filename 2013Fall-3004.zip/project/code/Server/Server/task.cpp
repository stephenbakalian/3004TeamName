#include "task.h"

Task::Task()
{
    setTaUsername("Unknown");
    setTitle("NoTitle");
    setDutiesGoals("NoDutiesGoals");
    setEvaluationData(NULL);
    setTaskID(-1);
}

Task::Task(int taskID, std::string title, std::string dutiesGoals){
    setTaUsername("Unknown");
    setTaskID(taskID);
    setTitle(title);
    setEvaluationData(NULL);
    setDutiesGoals(dutiesGoals);
}

Task::Task(int taskID,std::string username,  std::string title, std::string dutiesGoals){
    setTaskID(taskID);
    setTaUsername(username);
    setTitle(title);
    setEvaluationData(NULL);
    setDutiesGoals(dutiesGoals);
}

Task::Task(int taskID, std::string username, std::string title, std::string dutiesGoals, EvaluationData *evaluationData){
    setTaskID(taskID);
    setTaUsername(username);
    setTitle(title);
    setDutiesGoals(dutiesGoals);
    setEvaluationData(evaluationData);
}

std::string Task::getTitle() const
{
    return title;
}

void Task::setTitle(const std::string &value)
{
    title = value;
}
std::string Task::getDutiesGoals() const
{
    return dutiesGoals;
}

void Task::setDutiesGoals(const std::string &value)
{
    dutiesGoals = value;
}
EvaluationData *Task::getEvaluationData() const
{
    return evaluationData;
}

void Task::setEvaluationData(EvaluationData *value)
{
    evaluationData = value;
}
int Task::getTaskID() const
{
    return taskID;
}

void Task::setTaskID(int value)
{
    taskID = value;
}
std::string Task::getTaUsername() const
{
    return taUsername;
}

void Task::setTaUsername(const std::string &value)
{
    taUsername = value;
}
