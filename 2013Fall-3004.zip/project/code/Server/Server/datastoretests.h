#ifndef DATASTORETESTS_H
#define DATASTORETESTS_H

#include "datastore.h"

class datastoretests
{
public:

    datastoretests();
    bool getAllUsers();


    /***** Get specific user from datastore   ******/
    bool getSpecificUser(std::string username);

    /***** Add a User *****/
    bool addUserTest();
    /**** Delete a User *****/
    bool deleteUserTest(std::string username);


    /********* TASKS *********/

    /**** Get all tasks *****/
    bool getAllTasks();




    /******** Add Task   *********/
    bool addTask();
    /***** Edit Task *****/
    bool editTask();
    /**** Delete Task  ******/
    bool deleteTask();



    /******* COURSES  ********/


    /***** Get all Courses ****/
    bool getAllCourses();

    /***** Add a Course ******/
    bool addCourse();

    /*****  Edit a Course ****/
    bool editCourse();

    /***** Delete a Course  ******/
    bool deleteCourse();


private:
    DataStore data;
    int i;
};

#endif // DATASTORETESTS_H
