#ifndef USER_H
#define USER_H

#include <string>

//#include "datastore.h"

/******** MUST MATCH ENUM IN clientrequest.h on Client ********/
enum UserType {TA_USER, INSTRUCTOR_USER, ADMINISTRATOR_USER};
/**************************************************************/

class User
{
public:
    User();
    User(std::string name, std::string pass);
    User(std::string name, std::string pass, UserType type);
    ~User();
    std::string getUsername() const;
    void setUsername(const std::string &value);

    std::string getPassword() const;
    void setPassword(const std::string &value);

    UserType getUserType() const;
    void setUserType(const UserType &value);

    // Attempts to get a user by this username
    // Initializes all data if they exist, otherwise destroys themselves
    bool getUser(std::string username);

private:
    std::string username;
    std::string password;
    UserType   userType;
};

#endif // USER_H
