#ifndef INSTRUCTORAPI_H
#define INSTRUCTORAPI_H

#include <QString>

#include "applogic.h"

class InstructorAPI
{
public:
    InstructorAPI();
    ~InstructorAPI();
    // View specific task
    QString viewTask(QStringList*);
    // view all courses for Instructor
    QString viewCourses(std::string username);
    // add task to TA
    QString addTask(QStringList *input);
    // edit existing task for a TA
    QString editTask(QStringList *input);
    // add evaluation to task for a ta
    QString evaluateTask(QStringList *input);
    // view all tasks for a specific ta
    QString viewTasksForTA(QStringList *input);
    // delete a specific task
    QString deleteTask(QStringList *input);
    // view all TAs for a course
    QString viewTAsForCourse(QStringList *input);

private:
    AppLogic *appLogic;
//    DataStore *ds;
//    DataStore data;

};

#endif // INSTRUCTORAPI_H
