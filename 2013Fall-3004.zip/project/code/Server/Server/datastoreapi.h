#ifndef DATASTOREAPI_H
#define DATASTOREAPI_H

#include "vector"
#include "QMutex"

#include "datastore.h"

class DataStoreAPI
{
public:
    DataStoreAPI();
    ~DataStoreAPI();
    //    Create
    bool addUser(User* user);
    bool addTask(Task* task);
    bool addCourse(Course* course);
    //    Read
    // Users
    bool getUser(QString username, User *user);
    int getAllUsers(std::vector<User*> *users);
    //Courses
    bool getCourse(int courseID, Course* course);
    int getAllCourses(std::vector<Course*> *courses);
    // Task
    bool getTask(int taskID, Task *task);
    int getAllTasks(std::vector<Task*> *tasks);
    //    Update
    bool updateUser(User *user);
    bool updateCourse(Course *course);
    bool updateTask(Task *task);
    //    Destroy
    bool deleteUser(QString username);
    bool deleteCourse(int courseID);
    bool deleteTask(int taskID);

private:
    DataStore *ds;
    QMutex mutex;
};

#endif // DATASTOREAPI_H
