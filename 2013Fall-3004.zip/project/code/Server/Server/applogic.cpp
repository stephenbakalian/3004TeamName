#include "applogic.h"

// DE/CONSTRUCTOR
AppLogic::AppLogic()
{
    commonLogic = new CommonLogic(&ds);
    instructorLogic = new InstructorLogic(&ds);
}

AppLogic::~AppLogic()
{
    delete(commonLogic);
    delete(instructorLogic);
}

// GETTERS AND SETTERS - nothing special here //
CommonLogic *AppLogic::getCommonLogic() const
{
    return commonLogic;
}

void AppLogic::setCommonLogic(CommonLogic *value)
{
    commonLogic = value;
}

InstructorLogic *AppLogic::getInstructorLogic() const
{
    return instructorLogic;
}

void AppLogic::setInstructorLogic(InstructorLogic *value)
{
    instructorLogic = value;
}
