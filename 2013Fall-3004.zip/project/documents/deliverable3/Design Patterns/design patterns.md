Client
======

Current
-------

Strategy design pattern (maybe Command)
  * All API calls calls triggered from logic derived from UI interactions
  * Based on the current form and signal/event emitted by the client, the 
  associated event is processed.

State design pattern
  * Representing the current users's UI form interaction states and the 
  various states they can transition into. 

Potential
---------
Observer design pattern
  *	User subscribes by logging into system;
  *	System logs actions based on asset I.D. (e.g. edit task ID = 123);
  *	Notified of changes to assets it is currently viewing (current user is 
  informed - maybe a popup dialog box - that the data they are currently 
  viewing is stale);

    *	Don’t need to push updates directly, relies on user to refresh when 
    desired;
  *	Allows for repository/MVC (maybe just Model-View in this case) architecture
  styles for clients.

Memento design pattern
  * To enable clients to roll back a series of transactions, perhaps with a 
  journal system;
  * Can support undo operations at a global level, aside from simple fetch 
  queries.

------------

Server
======

Current
--------
Façade design pattern


Interpreter design pattern
  * Translates API calls to their corresponding events, in relation to 
  operations with storage.

Potential 
---------
Mediator design pattern
  * Perhaps to help seperate the persistance layer
  
Prototype design pattern
  * 
