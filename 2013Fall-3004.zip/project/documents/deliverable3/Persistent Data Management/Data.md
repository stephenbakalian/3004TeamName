#Persistent Data Management

Our server uses flat files as a strategy for storing persistent data. This has allowed us to optimize the storage for size and speed, furthermore it puts our application in control regarding issues of concurrent access and loss of data. Although other options may have added benefits regarding race conditions on data access, the tradeoff was that we have a very simple data storage solution tailored to our system and its requirements. One particular benefit of using XML was that we were able to model our data after real objects in the system. Data that represents objects are elements in the XML file whereas class attributes are stored as attributes for such an element. Our storage system uses three XML files, Courses.xml, Tasks.xml, and Users.xml. Each file uses a key, which allows items within it to be referenced. The Courses and Tasks both use a unique ID while the Users use the username, which has to be unique, to identify entries. The way that the data is split up stops it from being repeated anywhere. An issue potentially presented by our data storage method is that if a user is deleted then the data store on it's own wouldn't be able to adjust, since flat files do not have any such sort of mechanism built in. We avoided this issue by ensuring that, in our data store logic, any time an object is deleted, any references to it are also deleted.

We have the following objects in our persistent storage, with their respective attributes listed below them:

Users:
- String username
- String password
- int user_type (enum dictating which type of user it is)

Courses:
- int id
- int code
- char section
- string term
- int year
- String instructor
- List<String> TAs (list of 0 or more TA usernames)

Tasks:
- int id
- String ta_username
- String title
- String dutiesGoals
- object evalData (only present if task has been evaluated, and is comprised of the following:)
-- int evaluation
-- String feedback
