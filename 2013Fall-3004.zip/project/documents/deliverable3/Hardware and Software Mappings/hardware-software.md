TAEval Hardware/Software Mapping
================================

TAEval will have two hardware components. The UserMachine, and the ServerMachine.

The UserMachine communicates with the ServerMachine via TCP/IP, and the ServerMachine will save all neccessary data to disk.

```
 ClientRequest | The ClientRequest subsystem is responsible for
               | generating and handling TCP/IP requests and
               | responses from the server. 
-----------------------------------------------------------------
 Server        | The Server subsystem is responsible for 
               | listening for incoming connections from the 
               | client, and allocating a Controller to handle
               | the request.
-----------------------------------------------------------------
 Controller    | The Controller subsystem is responsible for 
               | parsing requests, and then using DataStore to
               | save state.                                  
-----------------------------------------------------------------
 DataStore     | The DataStore subsystem saves all necessary
               | to disk.
```
