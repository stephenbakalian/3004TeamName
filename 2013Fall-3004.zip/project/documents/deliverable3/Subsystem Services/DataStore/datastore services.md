#DataStore Services
##Create
This service allows for the creation of persistent data that exists in our system. It takes objects that are created by the application logic and stores them into the XML data.
- createUser - to create new users for the system would take a user object as a parameter to be stored in Users.xml
- createTask - to create new tasks for the system would take a task object as a parameter to be stored in Tasks.xml
- createCourse - to create new course for the system would take a course object as a parameter to be stored in Courses.xml
##Read
This service reads the XML data and creates instances of objects that are stored in order for the application logic to use them.
- getUser - this would return an instance of a user specified by its username
- getAllUseres - this would return all users
- getCourse - This returns a course specified by its course code
- getAllCourses - This returns a list of all course objects
- getTask - This takes a taskid and returns a task object
- getAllTasks - This returns a list of all the task objects
##Update
This service allows for the application logic to update data stored in the datastore. These functions will update the persistent data stored in the XML files.
- updateUser - Takes a user object for an existing user, stores their new data in the Users.xml file.
- updateTask - Takes a task object for an existing task, if the task has evaluationData instantiated, stores their new data in the Tasks.xml file.
- updateCourse - Takes a course object as a parameter and replaces the info in Courses.xml
##Destroy
This service allows for the deletion of persistent data by the application logic.
- deleteUser - Takes a username as a parameter and deletes the user from the Users.xml file.
- deleteTask - Takes a taskID as a parameter and deletes the associated task from the Tasks.xml file.
- deleteCourse - Takes a courseID as a parameter and deletes the associate course from Courses.xml