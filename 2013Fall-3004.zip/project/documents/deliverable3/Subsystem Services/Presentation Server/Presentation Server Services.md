#Presentation Server Services
The presentation server presents a set of Application Programming Interfaces for our server which allow for any client that connects using the appropriate protocol, and is aware of the correct format of requests, to call functions to interact with the server. This allows us to protect function calls based on user type while, at a lower level avoiding repeating ourself.

##CommonAPI
This is a set of API calls that are common to all connecting users regardless of their user type.
- Connect - This function is called on the server when a client connects and spins up a new thread on the server to handle client requests.
- Login - Takes a username and sends it down to the appropriate logic to determine validity of the username. If valid an instance of the user is returned and kept in order to authenticate the connection for future calls
- Logout - Destroys the connected user object.
- Disconnect - In the case client disconnects destroys the user object and cleans up the connection.

##TAAPI
This is a set of function calls that are specific to the TA user are here. If a user is authenticated as a TA user then they only have access to these functions (in addition to the CommonAPI functions).

- viewtasks - returns a carriage return separated list of tasks for the authenticated user
- viewtask - takes a taskID returns carriage separated list of data to describe the task


##InstructorAPI
The InstructorAPI Service is a set of functions exposed by the Presentation Server Subsystem that covers the scope of all function calls the Instructor user has permissions on in the system. Instructor Users have access to all TA functions in addition to these.

- viewcourses - Calls the appropriate function in the Application Logic to get a list of all courses. Returns a carriage return separated list of all courses for the authenticated user
- addtask - Used to add a task to a specified user, takes a carriage return separated list of data to create a task object prepended by the TAs username. Parses the request and calls relevant Logic Subsystem function
- edittask - Takes a carriage return separated list of task data prepended by the taskID of the task to modify. Calls the relevant Logic Subsystem function with the appropriate data.
- evaluatetask - Takes a carriage return separated list of evaluation data prepended by the taskId of the task to be modified, calls the associated Application Logic function.
- deletetask - Takes a taskID as a parameter and calls the appropriate Logic Subsystem function to process the request.
- viewtasforcourse - Takes a courseID as a parameter and returns a carriage return separated list of courses.


##AdminAPI
The AdminAPI Service is a set of functions exposed for users that authenticate as Administrator user type. They cover the scope of all the potential use cases for any administrators. They require the current user be logged in as a Administrator User.

- viewusers - Returns a carriage return separated list of all usernames and user types for all users in system
- adduser - Takes a Carriage return separated set of data to create a new user in the system. Parses the data and calls the appropriate Application Logic function to delete the user.
- edituser - Takes a Carriage return separated set of data to modify a user in the system. Parses the data and calls the appropriate Application Logic function to edit the user.
- deleteuser - Takes a username for a user, calls the appropriate Application Logic function to delete the user.
- viewcourse - Takes a courseID as a parameter and calls the appropriate Application Logic to get the Course data, returns a carriage return separated list of data on the course.
- addcourse - Takes a carriage return separated list of data to create a course object, parses it and calls the appropriate application logic function.
- editcourse - Takes a carriage return separated list of data to edit a course object, parses it and calls the appropriate application logic function.
- deletecourse - Takes a courseID as a parameter, calls the appropriate Application Logic function to handle deleting a course.
- listreports - Calls the Application Logic to get a all the report specifications, returns a carriage return separated list of reportTypes.
- generatereport - Takes a report type as a parameter, calls the Application Logic to get all relevant information, packages it in a carriage return separated list set of data.


