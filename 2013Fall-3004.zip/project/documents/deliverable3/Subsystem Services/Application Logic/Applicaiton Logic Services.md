#Application Logic Services
The Application Logic Services is a set of function calls that are exposed in the middle of our server in order to avoid repeating ourself and to implement the actual logic required to manipulate the objects in our system. It handles all requests from the Presentation Server and accesses functions exposed by the DataStore to retrieve and manipulate persistent data for the system.

##Common Logic
This service exposes all logic that is used by more than one of the different user types. It is kept here to ensure that if one user type was removed from the system it would not break the functionality of the remaining users.

- viewTasksForUser
- viewTask
- viewCoursesForUser
- viewTAsForCourse

##TALogic
This service is were any TA specific logic would be stored. At this time there is nothing that is specific to a TA however in order for the System to remain expandable, for example if in the future, if a complete task action were added then the logic to complete this would go here. 

##Instructor Logic
This service exposes all application logic that is specific to actions performed by the instructor user.
- addTask
- editTask
- evaluateTask
- deleteTask

##Admin Logic
This service is there for all the application logic which is only required by users authenticated as an Admin.

