HIGH LEVEL:
UC01     	View Tasks
UC02    	Manage Assigned Courses
UC03    	Manage Courses
UC04    	Generate Reports
UC05    	Manage Users

UC01	  	View Tasks
UC01.1 		Evaluations

UC02	  	Manage Assigned Courses
UC02.1 		List Assigned Courses
UC02.2		List TA's for Course
UC02.3  	Modify Task for TA
UC02.3.1 	Add Task to TA
UC02.3.2 	Evaluate Task
UC02.3.3 	Edit Task
UC02.3.4 	Delete Task

UC03 	  	Manage Courses
UC03.1		List Courses
UC03.2		Add Courses
UC03.3		Add TA to Course
UC03.4		Edit Course
UC03.5		Delete Course

UC04	  	Generate Reports

UC05	  	Manage Users
UC05.1 		Add User
UC05.2 		Edit User
UC05.3 		Delete User
UC05.4 		List Users
