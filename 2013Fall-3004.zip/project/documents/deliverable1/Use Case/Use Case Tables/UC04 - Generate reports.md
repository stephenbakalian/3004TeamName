**Use case name**: 			Generate reports

**Participating actors**: 	Iniatiated by Administrator, communicates with Window, DataStore, and DataVisualizer.

**Flow of events**: 		1. The _Administrator_ initiates the Generate Reports action
							
							2. The _Administrator_ selects the desired report type to be generated.

							3. The _Administrator_ clicks the `Generate` button.

							4. The _DataVizualizer_ requests data from _DataStore_, and returns that to _Window_.

							5. Window displays the data.

**Entry condition**: 		The _Administrator_ must be logged in.

**Exit condition**:			

**Quality requirements**: 	* The _Administrator_ should be notified if there is not sufficient data to generate reports using.
							* The reports should take no longer than 10 seconds to complete.

**Traceability**: 			UC04, FR1, FR3.3 - 01, NFR??