Requirements
===
*This directory is to store any docuemntation regarding to our system requirements*
---

So far just a basic overview of requirements for first assignment.

Link:

[COMP 3004 - Phase 1 Model - Requirements Analysis](http://goo.gl/kkGtWJ)
